import { Navigation } from 'react-native-navigation'
import * as types from './constants/types'

import Drawer from './containers/drawer/Drawer'
import Language from './containers/language/Language'
import SetupWallet from './containers/setupWallet/SetupWallet'
import RestoreWallet from './containers/restoreWallet/RestoreWallet'
import TermOfService from './containers/termOfService/TermOfService'
import PrivacyPolicy from './containers/privacyPolicy/PrivacyPolicy'
import WalletTop from './containers/walletTop/WalletTop'
import PinCode from './containers/pinCode/PinCode'
// PinCodeSetting
import PinCodeSetting from './containers/pinCode/PinCodeSetting'
// MenuView
import MenuView from './containers/drawer/MenuView'

// setPinCode
import { setPinCode } from './actions/pinCodeActions'
import { setAccount } from './actions/accountActions'
import { setCurrency } from './actions/currencyActions'
import { setLanguage } from './actions/language'
import { setToken } from './actions/mainAction'

import { initState } from './global/global-constants'

import { checkStoreRedux } from './lib/createReducer'

import DisplayBackupPhrase from './containers/displayBackupPhrase/DisplayBackupPhrase'
import DisplayPrivateKey from './containers/displayPrivateKey/DisplayPrivateKey'
import AboutNoahWallet from './containers/aboutNoahWallet/AboutNoahWallet'
import QrCodeScanner from './containers/qrCode/QrCodeScanner'
import SplashScreen from './containers/SplashScreen/SplashScreen'

// register all screens of the app (including internal ones)
export function registerScreens (store, Provider) {
  checkStoreRedux(store, types.SET_PINCODE, setPinCode, initState.initPin)
  checkStoreRedux(store, types.SET_ACCOUNT, setAccount, initState.initData)
  checkStoreRedux(store, types.SET_LANGUAGE, setLanguage, initState.initLanguage)
  checkStoreRedux(store, types.SET_CURRENCY, setCurrency, initState.initCurrency)
  checkStoreRedux(store, types.SET_TOKEN, setToken, initState.initCurrency)
  Navigation.registerComponent('noah.Drawer', () => Drawer, store, Provider)
  Navigation.registerComponent('noah.Language', () => Language, store, Provider)
  Navigation.registerComponent('noah.SplashScreen', () => SplashScreen, store, Provider)
  Navigation.registerComponent('noah.SetupWallet', () => SetupWallet, store, Provider)
  Navigation.registerComponent('noah.RestoreWallet', () => RestoreWallet, store, Provider)
  Navigation.registerComponent('noah.TermOfService', () => TermOfService, store, Provider)
  Navigation.registerComponent('noah.PrivacyPolicy', () => PrivacyPolicy, store, Provider)
  Navigation.registerComponent('noah.WalletTop', () => WalletTop, store, Provider)
  Navigation.registerComponent('noah.PinCode', () => PinCode, store, Provider)
  Navigation.registerComponent('noah.PinCodeSetting', () => PinCodeSetting, store, Provider)
  Navigation.registerComponent('noah.MenuView', () => MenuView, store, Provider)
  Navigation.registerComponent('noah.DisplayBackupPhrase', () => DisplayBackupPhrase, store, Provider)
  Navigation.registerComponent('noah.DisplayPrivateKey', () => DisplayPrivateKey, store, Provider)
  Navigation.registerComponent('noah.AboutNoahWallet', () => AboutNoahWallet, store, Provider)
  Navigation.registerComponent('noah.QrCodeScanner', () => QrCodeScanner, store, Provider)
}
