import React from 'react'
import { Text } from 'react-native'

export default function CustomText ({
  children,
  style,
  ...props
}) {
  return (
    <Text
      {...props}
      style={[style, {fontFamily: 'utmAvo'}]}
    >
      {children}
    </Text>
  )
}

export function CustomTextBold ({
  children,
  style,
  ...props
}) {
  return (
    <Text
      {...props}
      style={[style, {fontFamily: 'utmAvoBold'}]}
    >
      {children}
    </Text>
  )
}
