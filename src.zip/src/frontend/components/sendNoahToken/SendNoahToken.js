import React, { Component } from 'react'
import { View, TouchableOpacity, Image, Animated, Keyboard, Text } from 'react-native'
import { width, height } from 'react-native-dimension'
import { connect } from 'react-redux'
import { setBalance } from '../../actions/mainAction'
import { bindActionCreators } from 'redux'
import styles from './styles'
import { WalletTopComponents, ComponentTransitionType } from '../../constants/constants'
import Images from '../../constants/images'
import CustomText, { CustomTextBold } from '../../components/CustomText/CustomText'
import i18n from '../../global/translations'
import { commaGlobal } from '../../global/global-constants'
import _ from 'lodash'
import InputError from '../../components/textInput/InputError'

/**
 * NAME: SendNoahToken
 * CREATOR: Chau
 * Send user token to another
 */
class SendNoahToken extends Component {
  constructor (props) {
    super(props)
    this.goToSendComfirmScreen = this.goToSendComfirmScreen.bind(this)
    this.cancelSendToken = this.cancelSendToken.bind(this)
    this.openScanQRCode = this.openScanQRCode.bind(this)
    this.state = ({
      revAddress: '',
      addressError: false,
      amountError: false,
      revAmount: '',
      qrCode: false,
      disabled: 'none',
      opacityNumber: new Animated.Value(0.5),
      selectionAddress: null,
      selectionAmount: null,
      // Animated input
      addressErrAnim: new Animated.Value(0),
      shakeAddressAnim: new Animated.Value(0),
      ethErrAnim: new Animated.Value(0),
      shakeEthAnim: new Animated.Value(0)
    })
  }

  // Animation control Start
  addressErrActive () {
    Animated.timing(
      this.state.addressErrAnim, {
        toValue: this.state.addressError ? 1 : 0,
        duration: 400
      }
    ).start(!this.state.addressError && this.state.shakeAddressAnim.setValue(0))
  }

  shakeAnimation () {
    Animated.spring(
      this.state.shakeAddressAnim, {
        toValue: this.state.addressError ? 1 : 0,
        friction: 4,
        tension: 1
      }
    ).start()
  }

  shakeEthAnimation () {
    Animated.spring(
      this.state.shakeEthAnim, {
        toValue: this.state.ethErrAnim ? 1 : 0,
        friction: 4,
        tension: 1
      }
    ).start()
  }

  ethErrActive () {
    Animated.timing(
      this.state.ethErrAnim, {
        toValue: this.state.amountError ? 1 : 0,
        duration: 400
      }
    ).start(!this.state.amountError && this.state.shakeEthAnim.setValue(0))
  }

  /**
   * FUNCTION: componentWillReceiveProps
   * @param {*} props 
   * Receive qrCode from scan Qrcode View
   */
  componentWillReceiveProps (props) {
    if (props.qrCode) {
      let qrCodeValue = props.qrCode
      let qrCodeArr = qrCodeValue.split(commaGlobal.semicolon)
      let revAddressTemp = qrCodeArr[0] || ''
      let revAmountTemp = qrCodeArr[1] || ''

      this.setState({revAddress: revAddressTemp, revAmount: revAmountTemp})
      if (this.validateString(revAddressTemp)) {
        this.isAddressValid(revAddressTemp, true)
      }

      const self = this
      setTimeout(function () {
        self.setState({selectionAddress: {start: 0, end: revAddressTemp.length - 1}}, () => self.setState({selectionAddress: {start: 0, end: 0}}))

        if (self.validateNumber(revAmountTemp)) {
          self.isAmountValid(revAmountTemp)
          self.setState({selectionAmount: {start: 0, end: revAmountTemp.length - 1}}, () => self.setState({selectionAmount: {start: 0, end: 0}}))
        }
      }, 150)
    }
    if (props.isClear) {
      this.setState({revAddress: '', revAmount: ''})
      this.visibilityTransform()
    }
  }

  /**
   * FUNCTION visibilityTransform
   * PARAM: bgTo ->  opacity value
   * set visibility opacity 
   */
  visibilityTransform (_addressError, _amountError, _revAddress, _revAmount) {
    if (_addressError === false && _amountError === false && _revAddress && _revAmount && Number(_revAmount) > 0) {
      this.setState({
        disabled: 'box-none'
      })
      bgTo = 1
    } else {
      bgTo = 0.5
      this.setState({
        disabled: 'none'
      })
    }
    Animated.timing(this.state.opacityNumber, {
      toValue: bgTo,
      delay: 0,
      duration: 300
    }).start()
  }
  /**
   * Go to SendComfirm Screen
   */
  goToSendComfirmScreen () {
    this.props.changeParentComponentID(WalletTopComponents.CONFIRM_SEND_TOKEN,
      ComponentTransitionType.SlideUp, this.state.revAddress, this.state.revAmount)
    const self = this
    setTimeout(function () {
      self.setState({
        addressError: false,
        amountError: false
      })
      self.visibilityTransform(false, false, self.state.revAddress, self.state.revAmount)
    }, 100)
  }
  /**
   * cancelSendToken: go back to transaction history
   */
  cancelSendToken () {
    this.props.changeParentComponentID(WalletTopComponents.TRANSACTION_HISTORY,
      ComponentTransitionType.SlideDown, this.state.revAddress, this.state.revAmount)
    this.props.updateOldBalance(false, '')
    const self = this
    setTimeout(function () {
      self.setState({
        revAddress: '',
        revAmount: '',
        addressError: false,
        amountError: false

      })
      self.state.addressErrAnim.setValue(0)
      self.state.shakeAddressAnim.setValue(0)
      self.state.ethErrAnim.setValue(0)
      self.state.shakeEthAnim.setValue(0)

      self.visibilityTransform()
    }, 100)
  }
  /**
   * openScanQRCode: open scanQR code screen
   */
  openScanQRCode () {
    Keyboard.dismiss()
    this.props.openQRScanner()
  }
  /**
   * validate input
   */
  validateNumber = (number) => {
    var reg = /^([0-9_.]+)$/
    return reg.test(number)
  }
  validateString = (string) => {
    var reg = /^([A-Za-z0-9_]+)$/
    return reg.test(string)
  }
  check8Decimal (amount) {
    let arr = amount.split('.')
    if (arr.length === 2) {
      if (arr[1].length <= 8) {
        return true
      }
      return false
    } else if (arr.length > 2) {
      return false
    }
    return true
  }
  isAmountValid (amount) {
    if (this.validateNumber(amount) && this.check8Decimal(amount)) {
      this.setState({
        revAmount: amount
      })
      if (Number(amount) <= this.props.balance && Number(amount) > 0) {
        this.props.changeBalance((_.round((this.props.balance - Number(amount)), 8)).toFixed(8))
        this.setState({
          amountError: false
        }, () => {
          this.ethErrActive()
        })
        this.visibilityTransform(this.state.addressError, false, this.state.revAddress, amount)
      } else {
        this.setState({
          amountError: true
        }, () => {
          this.ethErrActive()
          this.shakeEthAnimation()
        })
        this.visibilityTransform(this.state.addressError, true, this.state.revAddress, amount)
      }
    } else {
      if (amount === '') {
        this.setState({
          revAmount: amount
        })
        this.props.changeBalance((_.round((this.props.balance - 0), 8)).toFixed(8))

        this.visibilityTransform(this.state.addressError, false, this.state.revAddress, amount)
        this.setState({
          amountError: false
        }, () => {
          this.ethErrActive()
        })
      }
    }
  }

  isAddressValid (address, qrCode) {
    if (!this.validateString(address)) {
      let oldAddress = this.state.revAddress
      this.visibilityTransform(true, this.state.amountError, address, this.state.revAmount)
      if (address.length === 0) {
        this.setState({ revAddress: '', addressError: false }, () =>
          this.addressErrActive()
        )
      } else {
        if (qrCode) {
          this.setState({ addressError: true, qrCode: true, revAddress: address }, () => {
            this.addressErrActive()
            this.shakeAnimation()
          })
        } else {
          this.setState({ revAddress: oldAddress, addressError: true }, () => {
            this.addressErrActive()
            this.shakeAnimation()
          })
        }
      }
    } else {
      if ((address.startsWith('0x') && address.length === 42)) {
        this.setState({ addressError: false }, () =>
          this.addressErrActive()
        )
        this.visibilityTransform(false, this.state.amountError, address, this.state.revAmount)
      } else {
        this.setState({ addressError: true }, () => {
          this.addressErrActive()
          this.shakeAnimation()
        })
        this.visibilityTransform(true, this.state.amountError, address, this.state.revAmount)
      }
      this.setState({ qrCode: false })
    }
    this.setState({ revAddress: address })
  }

  _onFocus (event, tag) {
    if (tag === 0) {
      if (!event) {
        this.setState({selectionAddress: {start: 0, end: 0}})
      } else {
        this.setState({selectionAddress: {start: this.state.revAddress.length, end: this.state.revAddress.length}}, () => this.setState({selectionAddress: null}))
      }
    } else {
      if (!event) {
        this.setState({selectionAmount: {start: 0, end: 0}})
      } else {
        this.setState({selectionAmount: {start: this.state.revAmount.length, end: this.state.revAmount.length}}, () => this.setState({selectionAmount: null}))
      }
    }
  }

  render () {
    const { selectionAddress, selectionAmount, disabled, revAddress, addressError, shakeAddressAnim, addressErrAnim, qrCode, revAmount, shakeEthAnim, ethErrAnim } = this.state
    return (
      <View style={{ height: height(65), width: width(92) }}>
        <View style={styles.addressStyle}>
          <CustomTextBold style={styles.title}>{i18n.t('SendNoahToken.Send')}</CustomTextBold>
          <View style={styles.line} />
        </View>
        <View style={styles.borderContain}>
          <View>

            {/* Address TextInput */}
            <InputError
              ref='addressInput'
              value={revAddress}
              txtHolder={i18n.t('SendNoahToken.Receiver')}
              containerStyle={styles.inputStyle}
              maxNum={42}
              inputStyle={styles.input}
              isError={addressError}
              btnViewRender={
                <TouchableOpacity onPress={this.openScanQRCode} style={styles.btnQRCode}>
                  <Image source={Images.ic_qrCopy} />
                </TouchableOpacity>
              }
              errorStyle={{
                transform: [
                  {
                    translateX: shakeAddressAnim.interpolate({
                      inputRange: [0, 0.1, 0.3, 0.4, 1],
                      outputRange: [0, 2, -2, -2, 0]
                    })
                  }
                ],
                borderColor: addressErrAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['white', '#ff0040']
                })
              }}
              returnKeyType='next'
              {
              ...selectionAddress ? { selection: selectionAddress } : null
              }

              onBlur={() => revAddress && this._onFocus(false, 0)}
              onFocus={() => this._onFocus(true, 0)}
              onChangeText={(text) => qrCode
                ? this.isAddressValid(text.trim(), true)
                : this.isAddressValid(text.trim())}

              onSubmitEditing = {(event) => {
                this.refs.amountInput.focus()
              }}
            />

            {/* Error Address */}
            <Animated.View style={{
              height: height(4),
              position: 'absolute',
              zIndex: -1,
              width: width(90),
              alignSelf: 'center',
              opacity: addressErrAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 1]
              }),
              transform: [{
                translateY: addressErrAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [height(8), height(8.5)]
                })
              }]
            }}>
              <Text style={{ color: '#ff0040' }}>{i18n.t('SendNoahToken.AddressError')}</Text>
            </Animated.View>

            {/* ETH Money TextInput */}
            <InputError
              ref='amountInput'
              value={revAmount}
              txtLabel={'NOAH'}
              txtHolder={i18n.t('SendNoahToken.Amount')}
              keyboardType={'numeric'}
              inputStyle={styles.input}
              containerStyle={styles.inputStyleAmount}
              onChangeText={(ethAmount) => this.isAmountValid(ethAmount.trim())}
              returnKeyType='go'
              {
              ...selectionAmount ? { selection: selectionAmount } : null
              }

              onBlur={() => revAmount && this._onFocus(false, 1)}
              onFocus={() => this._onFocus(true, 1)}
              errorStyle={{
                transform: [
                  {
                    translateY: addressErrAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0, height(1)]
                    })
                  },
                  {
                    translateX: shakeEthAnim.interpolate({
                      inputRange: [0, 0.1, 0.3, 0.4, 1],
                      outputRange: [0, 2, -2, -2, 0]
                    })
                  }
                ],
                borderColor: ethErrAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['white', '#ff0040']
                })
              }}/>

            {/* Error ETH Money */}
            <Animated.View style={{
              height: height(5.5),
              position: 'absolute',
              zIndex: -1,
              width: width(90),
              alignSelf: 'center',
              opacity: ethErrAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, 1]
              }),
              top: addressErrAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, height(1.5)]
              }),
              transform: [{
                translateY: ethErrAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [height(12), height(17.5)]
                })
              }]
            }}>
              <Text style={{ color: '#ff0040' }}>{i18n.t('SendNoahToken.AmountError')}</Text>
            </Animated.View>

          </View>

          <View style={styles.border2Button}>
            <View style={styles.borderButton} elevation={10}>
              <TouchableOpacity style={styles.btnCancelStyle} onPress={this.cancelSendToken}>
                <View style={styles.btnViewStyle}>
                  <CustomText style={styles.btnTextStyle}>{i18n.t('SendNoahToken.Cancel')}</CustomText>
                </View>
              </TouchableOpacity>
            </View>
            <View style={styles.borderButton} elevation={10}>
              <Animated.View pointerEvents={disabled} style={{ opacity: this.state.opacityNumber, flex: 1 }}>
                <TouchableOpacity style={styles.btnStyle} onPress={this.goToSendComfirmScreen}>
                  <View style={styles.btnViewStyle}>
                    <CustomText style={styles.btnTextStyle}>{i18n.t('SendNoahToken.Send')}</CustomText>
                  </View>
                </TouchableOpacity>
              </Animated.View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

//  Redux 
function mapStateToProps (state) {
  return {
    account: state.account,
    qrCode: state.qrCode,
    balance: state.balance
  }
}
function mapDispatchToProps (dispatch) {
  return {
    setBalance: bindActionCreators(setBalance, dispatch)
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(SendNoahToken)
