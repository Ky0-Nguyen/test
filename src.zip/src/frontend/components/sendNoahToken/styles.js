import { StyleSheet } from 'react-native'
import { colors } from '../../global/globalStyles'
import { width, height } from 'react-native-dimension'

const styles = StyleSheet.create({
  addressStyle: {
    paddingTop: height(1.5),
    paddingBottom: height(1)
  },
  line: {
    marginTop: height(2),
    height: width(0.2),
    backgroundColor: '#CED0D0'
  },
  title: {
    fontSize: width(4),
    color: 'black',
    textAlign: 'center'
  },
  borderContain: {
    flex: 1,
    padding: 1,
    justifyContent: 'space-between'
  },
  btnCancelStyle: {
    flex: 1,
    backgroundColor: '#7D7E7F'
  },
  borderButton: {
    width: width(45),
    height: width(13)
  },
  border2Button: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: width(1)
  },
  btnStyle: {
    flex: 1,
    backgroundColor: colors.primary
  },
  btnViewStyle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: colors.text2,
    borderWidth: width(0.2)
  },
  btnTextStyle: {
    color: colors.text2,
    fontSize: width(4)
  },
  btnQRCode: {
    width: width(8),
    height: width(8),
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: width(1.5)
  },
  inputStyle: {
    height: height(6),
    width: width(91),
    marginBottom: width(1),
    marginTop: width(4),
    borderColor: '#CED0D0',
    backgroundColor: 'white',
    borderWidth: width(0.4)
  },
  inputStyleAmount: {
    height: height(6),
    width: width(91),
    marginBottom: width(1),
    marginTop: width(2),
    borderColor: '#CED0D0',
    backgroundColor: 'white',
    borderWidth: width(0.4)
  },
  input: {
    flex: 1,
    fontSize: width(3.73),
    fontFamily: 'utmAvo',
    padding: width(1.5),
    color: 'black'
  },
  inputError: {
    flex: 1,
    fontSize: width(3.73),
    fontFamily: 'utmAvo',
    padding: width(1.5),
    color: 'red'
  },
  borderInput: {
    borderColor: '#CED0D0',
    borderWidth: width(0.2),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    marginTop: width(4),
    paddingLeft: width(2),
    paddingRight: width(2)
  },
  borderInputError: {
    borderColor: 'red',
    borderWidth: width(0.2),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    marginTop: width(4),
    paddingLeft: width(2),
    paddingRight: width(2)
  }
})

export default styles
