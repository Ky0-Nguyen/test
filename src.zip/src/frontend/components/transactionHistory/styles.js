import { StyleSheet } from 'react-native'
import { colors } from '../../global/globalStyles'
import { width, height } from 'react-native-dimension'

const styles = StyleSheet.create({
  coinAmountContainer: {
    marginTop: 7
  },
  container: {
    flex: 1,
    backgroundColor: '#DDDDDD'
  },
  navigator: {
    justifyContent: 'center'
  },

  menuIcon: {
    zIndex: 2,
    position: 'absolute'
  },

  navTitle: {
    textAlign: 'center',
    fontSize: width(4.5),
    color: colors.title
  },

  balanceContainer: {
    marginTop: width(2),
    backgroundColor: colors.primary,
    borderWidth: width(0.1),
    borderColor: colors.box,
    flexDirection: 'row',
    padding: width(2),
    justifyContent: 'space-between'
  },

  balanceBox: {
    justifyContent: 'space-between',
    paddingTop: width(1),
    paddingBottom: width(1)
  },

  balance: {
    fontSize: width(8),
    color: colors.text2
  },

  convertedBalance: {
    fontSize: width(5),
    color: colors.text2
  },

  qrCodeBox: {
    backgroundColor: 'white',
    padding: width(1)
  },

  addressStyle: {
    paddingTop: height(2),
    paddingBottom: height(0.5)
  },

  address: {
    color: colors.title,
    fontSize: width(4),
    flex: 9.2
  },

  line: {
    marginTop: height(2),
    height: width(0.2),
    backgroundColor: '#CED0D0'
  },
  buttonCopy: {
    width: width(4),
    height: width(4),
    alignItems: 'flex-end',
    justifyContent: 'center',
    flex: 0.8
  },

  itemContainer: {
    backgroundColor: colors.box,
    marginTop: width(3),
    padding: width(3)
  },

  itemText: {
    color: colors.title,
    fontSize: width(4)
  },

  actionContainer: {
    flex: 1.3,
    flexDirection: 'row',
    paddingTop: width(1),
    justifyContent: 'space-between'
  },

  btnStyle: {
    width: width(45),
    height: width(13),
    backgroundColor: colors.primary
  },

  btnViewStyle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: colors.text2,
    borderWidth: width(0.2)
  },

  btnTextStyle: {
    color: colors.text2,
    fontSize: width(4)
  },

  tooltipBox: {
    width: width(13),
    height: width(9),
    backgroundColor: 'white',
    zIndex: 2,
    position: 'absolute',
    justifyContent: 'center',
    alignSelf: 'center'
  },
  bottomText: {
    backgroundColor: '#7D7E7F',
    height: height(5),
    justifyContent: 'center'
  }
})

export default styles
