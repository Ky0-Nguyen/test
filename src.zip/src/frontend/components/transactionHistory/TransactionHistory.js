import React, { Component } from 'react'
import { View, TouchableOpacity, Image, Clipboard, FlatList, Animated, ActivityIndicator } from 'react-native'
import { width, height } from 'react-native-dimension'
import { connect } from 'react-redux'
import Images from '../../constants/images'
import styles from './styles'
import CustomText, { CustomTextBold } from '../../components/CustomText/CustomText'
import { WalletTopComponents, ComponentTransitionType } from '../../constants/constants'
import EthPlorerService from '../../services/ethplorerService'
import DateTimeUtil from '../../utils/datetimeUtil'
import i18n from '../../global/translations'
import PopoverTooltip from 'react-native-popover-tooltip'
import numeral from 'numeral'
import EtherLib from '../../lib/noahLibrary'

class TransactionHistory extends Component {
  constructor (props) {
    super(props)
    this.state = {
      account: this.props.account,
      _address: this.props.account.length > 0 ? this.props.account[0].address : '',
      refreshing: true,
      disabled: 'none',
      opacityNumber: new Animated.Value(0.5),
      dataSource: this.props.dataSource,
      opacityButtons: new Animated.Value(0.5),
      visible: false,
      isEmpty: false
    }
    this.gotoSendTokenView = this.gotoSendTokenView.bind(this)
    this.gotoReceiveTokenView = this.gotoReceiveTokenView.bind(this)
    this.handleRefresh = this.handleRefresh.bind(this)
    this.handleLoadMore = this.handleLoadMore.bind(this)
    this.onPressedCopy = this.onPressedCopy.bind(this)
    this.loadTransaction = this.loadTransaction.bind(this)
  }

  async componentWillMount () {
    if (this.props.internet) {
      _address = this.props.account.length > 0 ? this.props.account[0].address : ''
      const etheAmountLimit = 0.01
      try {
        this.setState({
          visible: true,
          isEmpty: false
        })
        this.loadTransaction()
        let etheAmount = await EtherLib.getEtherBalance(_address)
        if (etheAmount) {
          this.setState({
          // If (etheAmount < etheAmountLimit) -> disable Gass button
            disabled: etheAmount < etheAmountLimit ? 'none' : 'box-none',
            opacityNumber: etheAmount < etheAmountLimit ? 0.5 : 1
          })
        }
      } catch (error) {
        this.setState({
          visible: false
        })
      }
    } else {
      this.setState({
        isEmpty: true
      })
    }
  }

  /**
   * Load transaction from server
   */
  async loadTransaction () {
    _address = this.props.account.length > 0 ? this.props.account[0].address : ''
    const self = this
    var tokenArr = []

    if (_address.length > 0) {
      if (this.state.refreshing) {
        let datas = await EthPlorerService.getTokenTransactions(_address, this.props.tokenData.address)
        datas.operations.map((item, index) => {
          tokenArr.push({
            from: item.from,
            to: item.to,
            value: numeral(EtherLib.convertWeiToEther(item.value, this.props.tokenData.decimal)).format('0,0.00000000'),
            timeStamp: DateTimeUtil.convertTimestampToDateTime(item.timestamp)
          })
        })

        self.setState({
          visible: false,
          dataSource: tokenArr,
          loading: false,
          refreshing: false,
          isEmpty: !(tokenArr.length > 0)
        })
      }
    } else {
      self.setState({
        visible: false,
        loading: false,
        refreshing: false,
        isEmpty: true
      })
    }
  }

  /**
   * handle Refresh list
   */
  handleRefresh () {
    this.setState(
      {
        refreshing: true,
        isEmpty: false
      },
      () => {
        this.loadTransaction()
      }
    )
  }

  /**
   * handle LoadMore list
   */
  handleLoadMore () {
  }

  renderFooter = () => {
    if (!this.state.loading) return null
    return (
      <View style={{ paddingVertical: 20, borderTopWidth: 0, borderColor: 'white' }} >
        <ActivityIndicator animating size="small" color='white'/>
      </View>
    )
  }
  /**
  * gotoSendTokenView: go to SendNoahToken screen
  */
  gotoSendTokenView () {
    this.props.changeParentComponentID(WalletTopComponents.SEND_NOAH_TOKEN, ComponentTransitionType.SlideUp)
  }
  /**
   * gotoReceiveTokenView
   */
  gotoReceiveTokenView () {
    this.props.changeParentComponentID(WalletTopComponents.RECEIVE_TOKEN, ComponentTransitionType.SlideUp)
  }
  /**
  * Copy private key to clipboard
  */
  onPressedCopy () {
    let _address = this.props.account.length > 0 ? this.props.account[0].address : ''
    Clipboard.setString(_address)
    this.props.showAlert(i18n.t('TransactionHistory.Copied'))
  }

  componentWillReceiveProps (props) {
    if (props.visible !== null) {
      this.visibilityTransform(props.visible)
    }
  }

  /**
   * FUNCTION visibilityTransform
   * PARAM: bgTo ->  opacity value
   * set visibility opacity 
   */
  visibilityTransform (visible) {
    if (visible) {
      bgTo = 0.5
    } else {
      bgTo = 1
    }
    Animated.timing(this.state.opacityButtons, {
      toValue: bgTo,
      delay: 0,
      duration: 300
    }).start()
  }

  render () {
    const { disabled, isEmpty } = this.state
    var isLoading = this.props.visible ? 'none' : 'box-none'

    return (
      <View style={{ height: height(65), width: width(92) }} ref='TransactionHistory'>
        <View style={styles.addressStyle}>
          <View style={{ justifyContent: 'space-between', alignItems: 'center', flexDirection: 'row' }}>
            <CustomText style={styles.address} numberOfLines={1}>{i18n.t('TransactionHistory.Address')}: {this.props.account.length > 0 ? this.props.account[0].address : ''}</CustomText>
            <TouchableOpacity style={styles.buttonCopy} onPress={this.onPressedCopy.bind(this)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Image style={{ width: width(4), height: width(4), resizeMode: 'contain' }} source={Images.ic_copy} />
            </TouchableOpacity>
          </View>
          <View style={styles.line} />
        </View>
        <View style={{ flex: 1, justifyContent: 'space-between' }}>

          <View style={{ flex: 8.3 }}>
            {isEmpty &&
            <View style={{justifyContent: 'center', alignItems: 'center'}}>
              <CustomText style={{paddingTop: width(7), fontSize: width(3.5), zIndex: 2, position: 'absolute'}}>{i18n.t('TransactionHistory.Empty')}</CustomText>
            </View>
            }
            <FlatList
              style={{flex: 1}}
              data={this.state.dataSource}
              renderItem={({ item }) => this._renderItem(item)}
              keyExtractor={(item, index) => index}
              onRefresh={() => this.handleRefresh()}
              refreshing={this.state.refreshing}
              onEndReached={() => this.handleLoadMore()}
              ListFooterComponent={this.renderFooter}
              onEndReachedThreshold={0.5}
              scrollEventThrottle={200}
            />
          </View>

          <View style={styles.actionContainer}>
            <Animated.View pointerEvents={isLoading} style={{ opacity: this.state.opacityButtons, width: width(45), height: width(13) }}>
              <TouchableOpacity style={styles.btnStyle} onPress={this.gotoReceiveTokenView}>
                <View style={styles.btnViewStyle}>
                  <CustomText style={styles.btnTextStyle}>{i18n.t('TransactionHistory.Receive')}</CustomText>
                </View>
              </TouchableOpacity>
            </Animated.View>

            <View style={{ flex: 1, justifyContent: 'center' }}>
              <PopoverTooltip ref='tipGass'
                items={[ { label: i18n.t('TransactionHistory.GassTip'), onPress: () => {} } ]}
                buttonComponent= { <View/> }
                animationType='spring'
                overlayStyle={{ backgroundColor: 'transparent' }} // set the overlay invisible
                tooltipContainerStyle={{ borderRadius: width(1.6), justifyContent: 'center', alignSelf: 'center' }}
                labelContainerStyle={{ backgroundColor: 'white', width: width(92), height: 'auto', justifyContent: 'center', alignSelf: 'center' }}
                labelStyle={{ textAlign: 'justify', color: 'black', fontSize: width(3.47), fontFamily: 'utmAvo' }}
                elavation={10}
              />
              <View style={styles.tooltipBox}>
                <Animated.View pointerEvents={disabled} style={{ opacity: this.state.opacityNumber, flex: 1 }}>
                  <TouchableOpacity style={{ flex: 1, alignItems: 'center' }} onPress={() => this.refs.tipGass.toggle()}>
                    <CustomText style={{ color: 'green', fontSize: width(3) }}>{i18n.t('TransactionHistory.Gass')}</CustomText>
                    <Image source={Images.ic_gass} />
                  </TouchableOpacity>
                </Animated.View>
              </View>
            </View>

            <Animated.View pointerEvents={isLoading} style={{ opacity: this.state.opacityButtons, width: width(45), height: width(13) }}>
              <TouchableOpacity style={styles.btnStyle} onPress={this.gotoSendTokenView}>
                <View style={styles.btnViewStyle}>
                  <CustomText style={styles.btnTextStyle}>{i18n.t('TransactionHistory.Send')}</CustomText>
                </View>
              </TouchableOpacity>
            </Animated.View>
          </View>
        </View>
      </View>
    )
  }

  _renderItem = (item) => {
    isSend = (this.props.account.length > 0 ? this.props.account[0].address : '') === item.from
    strTitle = isSend ? (i18n.t('TransactionHistory.Sent')) : (i18n.t('TransactionHistory.Received'))

    return (
      <View style={styles.itemContainer}>
        <CustomTextBold style={styles.itemText} >{item.timeStamp}</CustomTextBold>
        <CustomText numberOfLines={1} style={styles.itemText} >
          <CustomText style={{color: isSend ? 'red' : 'green'}}>{strTitle}: </CustomText>
          {isSend ? item.to : item.from}
        </CustomText>
        <CustomText style={styles.itemText} >
          <CustomText style={{color: isSend ? 'red' : 'green'}}>{isSend ? '-' : '+'}{item.value}</CustomText> NOAH
        </CustomText>
      </View>
    )
  }
}
//  Redux 
function mapStateToProps (state) {
  return {
    account: state.account,
    tokenData: state.tokenData,
    internet: state.internet
  }
}
export default connect(mapStateToProps)(TransactionHistory)
