import React, { Component } from 'react'
import { View, TouchableOpacity, Animated, Text, TextInput, Keyboard } from 'react-native'
import { width, height } from 'react-native-dimension'
import { connect } from 'react-redux'
import styles from './styles'
import { WalletTopComponents, ComponentTransitionType } from '../../constants/constants'
import EtherLib from '../../lib/noahLibrary'
import CustomText, { CustomTextBold } from '../../components/CustomText/CustomText'
import i18n from '../../global/translations'
import Spinner from 'react-native-loading-spinner-overlay'

// value of pin code 
const MAX_LENGTH = 4

// make dot of pincode
function makeDots (num) {
  let ret = ''
  while (num > 0) {
    ret += ' ○ '
    num--
  }
  return ret
}
/**
 * NAME: ConfirmSendToken
 * CREATOR: Chau
 * Confirm sending token
 */
class ConfirmSendToken extends Component {
  constructor (props) {
    super(props)
    this.cancelSendToken = this.cancelSendToken.bind(this)
    this.state = ({
      contractAddress: props.tokenData.address,
      senderPrvKey: props.account[0].privateKey,
      senderAddress: props.account[0].address,
      sending: false,
      disabled: 'box-none',
      opacityNumber: new Animated.Value(1),
      valuePin: '',
      pincode: props.pincode,
      hideDot: true
    })
    this.onPressConfirm = this.onPressConfirm.bind(this)
    this.onChangeText = this.onChangeText.bind(this)
  }

  componentDidMount () {
    if (this.props.pincode) {
      this.setState({
        disabled: 'none',
        opacityNumber: new Animated.Value(0.5),
        hideDot: false
      })

      const self = this
      setTimeout(function () {
        self.refs.txtPin.focus()
        self.props.preventHideKeyboard('always')
      }, 600)
    }
  }
  /**
   * Go to SendComfirm Screen
   */
  async onPressConfirm () {
    this.setState({sending: true, disabled: 'none'})
    this.visibilityTransform(0.5)
    const self = this
    if (this.props.internet) {
      await EtherLib.sendTokenAction(this.state.senderAddress, this.state.senderPrvKey, this.props.revAddress, this.props.revAmount, this.state.contractAddress)
        .then(value => {
          self.setState({sending: false, disabled: 'box-none'})
          self.visibilityTransform(1)
          self.props.changeParentComponentID(WalletTopComponents.TRANSACTION_HISTORY, ComponentTransitionType.SlideDown)
          self.props.updateOldBalance(true, i18n.t('ConfirmSendToken.SendSuccess'))
        })
        .catch(error => {
          self.setState({sending: false, disabled: 'box-none'})
          self.visibilityTransform(1)
          self.props.showAlert(i18n.t('ConfirmSendToken.SendError'), 'error')
          if (error.message) {
            console.log(error.message)
          }
        })
    } else {
      this.setState({sending: false, disabled: 'box-none'})
      this.props.showToustInternet()
      this.visibilityTransform(1)
      setTimeout(function () {
        self.setState({showInternet: false})
      }, 2000)
    }
  }

  /**
   * cancelSendToken: go back to transaction history
   */
  cancelSendToken () {
    this.props.changeParentComponentID(WalletTopComponents.CONFIRM_SEND_TOKEN, ComponentTransitionType.SlideDown)
    this.props.updateOldBalance(false, '')
  }

  /**
   * validate input
   */
  validateNumber = (number) => {
    var reg = /^([0-9_.]+)$/
    return reg.test(number)
  }
  /**
   * FUNCTION: onChangeText
   * @param {*} text 
   */
  onChangeText (text) {
    if (this.validateNumber(text)) {
      if (text.length <= 4) {
        this.setState({
          valuePin: text
        })
        if (text === this.state.pincode) {
          this.setState({
            hideDot: true,
            opacityNumber: new Animated.Value(1),
            disabled: 'box-none'
          })
          this.props.preventHideKeyboard('never')
          Keyboard.dismiss()
        }
        if (text.length === 4 && text !== this.state.pincode) {
          this.props.showAlert(i18n.t('PinCode.Error'), 'error')
          const self = this
          setTimeout(function () {
            self.setState({
              valuePin: ''
            })
          }, 2500)
        }
      }
    } else {
      if (text.length === 0) {
        this.setState({
          valuePin: text
        })
      }
    }
  }

  visibilityTransform (bgTo) {
    Animated.timing(this.state.opacityNumber, {
      toValue: bgTo,
      delay: 0,
      duration: 500
    }).start()
  }

  render () {
    const { disabled, opacityNumber, sending } = this.state
    const { valuePin, hideDot } = this.state
    const marks = valuePin.replace(/./g, ' ● ')
    const dots = makeDots(MAX_LENGTH - valuePin.length)

    return (
      <View style={{ height: height(65), width: width(92) }}>
        <Spinner visible={sending} textContent={'Sending...'} textStyle={{ color: 'white', fontSize: 15 }} />
        {hideDot && <View style={styles.addressStyle}/>}
        {hideDot && (<CustomTextBold style={styles.title}>{i18n.t('TransactionHistory.Send')}</CustomTextBold>)}
        <View style={styles.line} />
        <View style={styles.borderContain}>
          <View>
            <CustomText style={[styles.textStyle, { marginTop: width(3) }]}>{i18n.t('ConfirmSendToken.ReceiverAccount')}</CustomText>
            <CustomText style={styles.textStyle}>{this.props.revAddress}</CustomText>
            <CustomText style={[styles.textStyle, { marginTop: width(3) }]}>{i18n.t('ConfirmSendToken.SenderAccount')}</CustomText>
            <CustomText style={styles.textStyle}>{this.state.senderAddress}</CustomText>
            <CustomText style={[styles.textStyle, { marginTop: width(3) }]}>{i18n.t('ConfirmSendToken.Amount')}</CustomText>
            <CustomText style={styles.textStyle}>{this.props.revAmount} NOAH</CustomText>
            {!hideDot && (
              <View style={{ flexDirection: 'column', margin: 0, padding: 0 }}>
                <View style={[styles.row, {marginBottom: height(1)}]} >
                  <Text style={[ styles.pin ]} >{marks}{dots}</Text>
                </View>
              </View>
            )}
          </View>
          <TextInput
            ref='txtPin'
            onChangeText={(text) => this.onChangeText(text)}
            returnKeyType='go'
            autoCapitalize='none'
            autoCorrect={false}
            style={{width: 0, height: 0}}
            keyboardType='numeric'
            value={this.state.valuePin}
            blurOnSubmit={false} />
          <View style={styles.border2Button}>
            <View style={styles.borderButton} elevation={10}>
              <TouchableOpacity style={styles.btnCancelStyle} onPress={this.cancelSendToken}>
                <View style={styles.btnViewStyle}>
                  <CustomText style={styles.btnTextStyle}>Cancel</CustomText>
                </View>
              </TouchableOpacity>
            </View>
            <View style={styles.borderButton} elevation={10}>
              <Animated.View pointerEvents={disabled} style={{ opacity: opacityNumber, flex: 1 }}>
                <TouchableOpacity style={styles.btnStyle} onPress={this.onPressConfirm}>
                  <View style={styles.btnViewStyle}>
                    <CustomText style={styles.btnTextStyle}>Confirm</CustomText>
                  </View>
                </TouchableOpacity>
              </Animated.View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

//  Redux 
function mapStateToProps (state) {
  return {
    account: state.account,
    tokenData: state.tokenData,
    pincode: state.pincode,
    internet: state.internet
  }
}
export default connect(mapStateToProps)(ConfirmSendToken)
