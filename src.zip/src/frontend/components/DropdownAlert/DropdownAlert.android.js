import React, { Component } from 'react'
import { StyleSheet, View, Text, TouchableHighlight, Animated, StatusBar, Platform, Image, PanResponder } from 'react-native'
import { width, height } from 'react-native-dimension'
import { txtMain } from './global-styles'
const StatusBarDefaultBarStyle = StatusBar._defaultProps.barStyle.value
const StatusBarDefaultBackgroundColor = StatusBar._defaultProps.backgroundColor.value
const DEFAULT_IMAGE_DIMENSIONS = 36
var closeTimeoutId = null
var panResponder

export default class DropdownAlert extends Component {
  constructor (props) {
    super(props)
    this.state = {
      animationValue: new Animated.Value(0),
      duration: 450,
      type: '',
      message: '',
      title: '',
      isOpen: false,
      startDelta: props.startDelta,
      endDelta: props.endDelta,
      topValue: 0
    }
    // Render
    this.renderButton = this.renderButton.bind(this)
    this.renderDropDown = this.renderDropDown.bind(this)
    // Action
    this.alert = this.alert.bind(this)
    this.alertWithType = this.alertWithType.bind(this)
    this.dismiss = this.dismiss.bind(this)
    this.onCancel = this.onCancel.bind(this)
    this.onClose = this.onClose.bind(this)
    // Util
    this.animate = this.animate.bind(this)
    // Pan Responder
    this.handlePanResponderMove = this.handlePanResponderMove.bind(this)
    this.handlePanResponderEnd = this.handlePanResponderEnd.bind(this)
    this.handleMoveShouldSetPanResponder = this.handleMoveShouldSetPanResponder.bind(this)
    this.handleStartShouldSetPanResponder = this.handleMoveShouldSetPanResponder.bind(this)
  }
  componentWillMount () {
    panResponder = PanResponder.create({
      onStartShouldSetPanResponder: this.handleStartShouldSetPanResponder,
      onMoveShouldSetPanResponder: this.handleMoveShouldSetPanResponder,
      onPanResponderMove: this.handlePanResponderMove,
      onPanResponderRelease: this.handlePanResponderEnd,
      onPanResponderTerminate: this.handlePanResponderEnd
    })
  }
  alert (title, message) {
    if (title === undefined) {
      title = null
    }
    if (message === undefined) {
      message = null
    }
    this.alertWithType('custom', title, message)
  }
  alertWithType (type, title, message) {
    if (this.validateType(type) === false) {
      return
    }
    if (typeof title !== 'string') {
      title = title.toString()
      console.warn('DropdownAlert: Title is not a string.')
    }
    if (typeof message !== 'string') {
      message = message.toString()
      console.warn('DropdownAlert: Message is not a string.')
    }
    if (this.props.replaceEnabled === false) {
      this.setState({
        type: type,
        message: message,
        title: title,
        isOpen: true,
        topValue: 0
      })
      if (this.state.isOpen === false) {
        this.animate(1)
      }
      if (this.props.closeInterval > 1) {
        if (closeTimeoutId != null) {
          clearTimeout(closeTimeoutId)
        }
        closeTimeoutId = setTimeout(function () {
          this.onClose('automatic')
        }.bind(this), this.props.closeInterval)
      }
    } else {
      var delayInMilliSeconds = 0
      if (this.state.isOpen === true) {
        delayInMilliSeconds = 475
        this.dismiss()
      }
      var self = this
      setTimeout(function () {
        if (self.state.isOpen === false) {
          self.setState({
            type: type,
            message: message,
            title: title,
            isOpen: true,
            topValue: 0
          })
        }
        self.animate(1)
        if (self.props.closeInterval > 1) {
          closeTimeoutId = setTimeout(function () {
            self.onClose('automatic')
          }, self.props.closeInterval)
        }
      }, delayInMilliSeconds)
    }
  }
  dismiss (onDismiss, action) {
    if (this.state.isOpen) {
      if (closeTimeoutId != null) {
        clearTimeout(closeTimeoutId)
      }
      this.animate(0)
      setTimeout(function () {
        if (this.state.isOpen) {
          this.setState({
            isOpen: false
          })
          if (this.props.updateStatusBar) {
            if (Platform.OS === 'android') {
              StatusBar.setBackgroundColor(this.props.inactiveStatusBarBackgroundColor, true)
            } else {
              StatusBar.setBarStyle(this.props.inactiveStatusBarStyle, true)
            }
          }
          if (onDismiss) {
            var data = {
              type: this.state.type,
              title: this.state.title,
              message: this.state.message,
              action: action // !!! How the alert was dismissed: automatic, programmatic, tap, pan or cancel
            }
            onDismiss(data)
          }
        }
      }.bind(this), (this.state.duration))
    }
  }
  onClose (action) {
    if (action === undefined) {
      action = 'programmatic'
    }
    this.dismiss(this.props.onClose, action)
  }
  onCancel () {
    this.dismiss(this.props.onCancel, 'cancel')
  }
  animate (toValue) {
    Animated.spring(
      this.state.animationValue, {
        toValue: toValue,
        duration: this.state.duration,
        friction: 9,
        useNativeDriver: (Platform.OS === 'ios')
      }
    ).start()
  }

  validateType (type) {
    if (type.length === 0 || type === null) {
      console.warn('Missing DropdownAlert type. Available types: info, warn, error or custom')
      return false
    }
    if (type !== 'info' && type !== 'warn' && type !== 'error' && type !== 'custom' && type !== 'success') {
      console.warn('Invalid DropdownAlert type. Available types: info, warn, error, success, or custom')
      return false
    }
    return true
  }
  handleStartShouldSetPanResponder (e, gestureState) {
    return this.props.panResponderEnabled
  }
  handleMoveShouldSetPanResponder (e, gestureState) {
    return gestureState.dx !== 0 && gestureState.dy !== 0 && this.props.panResponderEnabled
  }
  handlePanResponderMove (e, gestureState) {
    if (gestureState.dy < 0) {
      this.setState({
        topValue: gestureState.dy
      })
    }
  }
  handlePanResponderEnd (e, gestureState) {
    const delta = this.state.startDelta / 5
    if (gestureState.dy < delta) {
      this.dismiss(this.props.onClose, 'pan')
    }
  }
  renderText (text, style, numberOfLines, messageLength) {
    let newLength = messageLength >= 80 ? width(messageLength * 0.8) : 'auto'
    if (text != null) {
      if (text.length > 0) {
        return (
          <View style={{ width: newLength }}>
            <Text style={[txtMain, style]} numberOfLines={numberOfLines}>{text}</Text>
          </View>
        )
      }
    }
    return null
  }
  renderImage (type) {
    return (
      <View style={{ width: width(13) }}>
        <Image style={{ width: width(12.5), height: height(7) }} resizeMode='contain'
          {...(type === 'error'
            ? {
              source: require('./img/error.png')
            }
            : { source: require('./img/success.png') }
          ) } />
      </View>

    )
  }
  renderStatusBar (backgroundColor, barStyle, translucent) {
    if (Platform.OS === 'android') {
      StatusBar.setBackgroundColor(backgroundColor, true)
      StatusBar.setTranslucent(translucent)
    } else if (Platform.OS === 'ios') {
      StatusBar.setBarStyle(barStyle, true)
    }
  }
  renderButton (source, style, onPress, underlayColor, isRendered) {
    if (source != null && isRendered) {
      return (
        <TouchableHighlight style={{ opacity: 1, alignSelf: style.alignSelf, width: style.width, height: style.height }} onPress={onPress} underlayColor={underlayColor}>
          {this.renderImage(source, style)}
        </TouchableHighlight>
      )
    }
    return null
  }
  renderDropDown (isOpen) {
    if (isOpen === true) {
      var style = [styles.defaultContainer, StyleSheet.flatten(this.props.containerStyle)]
      var backgroundColor = this.props.containerStyle.backgroundColor
      switch (this.state.type) {
      case 'info':
        style = [styles.defaultContainer, { backgroundColor: this.props.infoColor }]

        backgroundColor = this.props.infoColor
        break
      case 'warn':
        style = [styles.defaultContainer, { backgroundColor: this.props.infoColor }]
        backgroundColor = this.props.infoColor
        break
      case 'error':
        style = [styles.defaultContainer, { backgroundColor: this.props.infoColor }]
        source = 'ios-close'
        backgroundColor = this.props.infoColor
        break
      case 'success':
        style = [styles.defaultContainer, { backgroundColor: this.props.infoColor }]
        source = 'ios-checkmark'
        backgroundColor = this.props.infoColor
        break
      }
      var activeStatusBarBackgroundColor = this.props.activeStatusBarBackgroundColor
      if (Platform.OS === 'android') {
        if (this.props.translucent) {
          style = [style, { paddingTop: StatusBar.currentHeight }]
        }
        if (this.state.type !== 'custom') {
          activeStatusBarBackgroundColor = backgroundColor
        }
      }
      if (this.props.updateStatusBar) {
        this.renderStatusBar(activeStatusBarBackgroundColor, this.props.activeStatusBarStyle, this.props.translucent)
      }

      let messageLength = 45 + this.state.message.length
      return (
        <View style={{ position: 'absolute', height: height(100), width: width(100) }}>
          <View style={{ position: 'absolute', opacity: 0.5, backgroundColor: 'black', height: height(100), width: width(100) }}/>
          <Animated.View
            {...panResponder.panHandlers}
            style={{
              transform: [{
                translateY: this.state.animationValue.interpolate({
                  inputRange: [0, 1],
                  outputRange: [this.state.startDelta, this.state.endDelta]
                })
              }],

              top: height(45),
              width: width(messageLength),
              alignSelf: 'center'
            }}>

            <TouchableHighlight
              onPress={(this.props.showCancel) ? null : () => this.onClose('tap')}
              underlayColor={backgroundColor}
              disabled={!this.props.tapToCloseEnabled}>

              <View style={[style, { opacity: 1 }]}>

                <View style={styles.textContainer}>
                  {this.renderImage(this.state.type)}
                  {this.renderText(this.state.message, StyleSheet.flatten(this.props.messageStyle), this.props.messageNumOfLines, messageLength)}
                </View>
                {this.renderButton(StyleSheet.flatten(this.props.cancelBtnImageStyle), this.onCancel, backgroundColor, this.props.showCancel)}
              </View>

            </TouchableHighlight>

          </Animated.View>
        </View>
      )
    }
    return null
  }
  render () {
    return (
      this.renderDropDown(this.state.isOpen)
    )
  }
}
DropdownAlert.defaultProps = {
  onClose: null,
  onCancel: null,
  closeInterval: 4000,
  startDelta: -height(100),
  endDelta: 0,
  titleNumOfLines: 1,
  messageNumOfLines: 3,
  imageSrc: null,
  infoColor: 'white',
  showCancel: false,
  tapToCloseEnabled: true,
  panResponderEnabled: true,
  replaceEnabled: true,
  containerStyle: {
    padding: 16,
    flexDirection: 'row'
  },
  titleStyle: {
    opacity: 1,
    textAlign: 'center',
    color: 'black',
    backgroundColor: 'transparent'
  },
  messageStyle: {
    opacity: 1,
    marginLeft: width(1),
    fontWeight: 'normal',
    color: 'black',
    backgroundColor: 'transparent'
  },
  imageStyle: {
    padding: 8,
    marginRight: width(5),
    width: DEFAULT_IMAGE_DIMENSIONS,
    height: DEFAULT_IMAGE_DIMENSIONS,
    alignSelf: 'center'
  },
  cancelBtnImageStyle: {
    padding: 8,
    width: DEFAULT_IMAGE_DIMENSIONS,
    height: DEFAULT_IMAGE_DIMENSIONS,
    alignSelf: 'center'
  },
  translucent: false,
  activeStatusBarStyle: 'light-content',
  activeStatusBarBackgroundColor: StatusBarDefaultBackgroundColor,
  inactiveStatusBarStyle: StatusBarDefaultBarStyle,
  inactiveStatusBarBackgroundColor: StatusBarDefaultBackgroundColor,
  updateStatusBar: true
}
var styles = StyleSheet.create({
  defaultContainer: {
    justifyContent: 'center',
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    height: height(15),
    backgroundColor: 'white'
  },
  textContainer: {
    justifyContent: 'center',
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    height: height(17),
    width: width(100),
    backgroundColor: 'white'
  }
})
