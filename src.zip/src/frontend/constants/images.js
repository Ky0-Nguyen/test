const images = {
  logo: require('../images/logo.png'),
  ic_menu: require('../images/menu.png'),
  ic_gass: require('../images/gass.png'),
  ic_copy: require('../images/copy.png'),
  ic_qrCopy: require('../images/qrCopy.png'),
  splash: require('../images/splash.png')
}

export default images
