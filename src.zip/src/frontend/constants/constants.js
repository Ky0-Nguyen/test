/**
 * Enum of screens in body of Wallet Top View
 */
export const WalletTopComponents = {
  TRANSACTION_HISTORY: 0,
  SEND_NOAH_TOKEN: 1,
  CONFIRM_SEND_TOKEN: 2,
  RECEIVE_TOKEN: 3
}

export const ComponentTransitionType = {
  SlideUp: 0,
  SlideDown: 1
}
