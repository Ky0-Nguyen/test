import { height, width } from 'react-native-dimension'

export const colors = {
  main: '#fef6df',
  primary: '#d4aa51',
  secondary: '#7F7F7F',
  text: '#000000',
  text2: '#FFFFFF',
  box: '#FFFFFF',
  title: '#343536'
}

export const background = {
  backgroundColor: colors.main,
  flex: 1,
  padding: width(4)
}

export const primaryButton = {
  backgroundColor: colors.primary,
  height: height(8),
  justifyContent: 'center',
  alignItems: 'center',
  borderColor: 'white',
  borderWidth: 0.3
}

export const secondaryButton = {
  backgroundColor: colors.secondary,
  height: height(8),
  justifyContent: 'center',
  alignItems: 'center'
}

export const navTitle = {
  color: colors.title,
  textAlign: 'center',
  fontSize: height(3),
  fontFamily: 'utmAvoBold'
}
export const navTitleMenu = {
  color: colors.title,
  textAlign: 'center',
  fontSize: height(3),
  fontFamily: 'utmAvo'
}
export const textDefault = {
  color: 'white',
  fontSize: height(2),
  fontFamily: 'utmAvo'
}
export const whilteLine = {
  height: height(0.1),
  width: width(100),
  backgroundColor: 'white'
}
export const colorsLink = {
  default: '#0C2342',
  link: '#219af1'
}
