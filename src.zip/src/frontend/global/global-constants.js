// Inject node globals into React Native global scope.
global.Buffer = require('buffer').Buffer
global.process = require('process')
global.process.env.NODE_ENV = global.process.env.NODE_ENV ? 'development' : 'development'

// Needed so that 'stream-http' chooses the right default protocol.
global.location = {
  protocol: 'file:'
}

global.crypto = {
  getRandomValues (byteArray) {
    for (let i = 0; i < byteArray.length; i++) {
      byteArray[i] = Math.floor(256 * Math.random())
    }
  }
}

export const initState = {
  initPin: '',
  initLanguage: '',
  initData: [],
  initCurrency: '',
  internetInit: true,
  initBalance: 0.00000000
}

export const commaGlobal = {
  comma: ',',
  semicolon: ';'
}

export const contractAddressNoah = '0x341c5c553853ade9a83c8036b230c30ed4089d6f'
export const tokenDecimalsNoah = 18

// Create key mapping for AsyncStorage
const keyAsync = {
  CryptoExchangeKey: 'CryptoExchangeKey'
}

export default keyAsync
