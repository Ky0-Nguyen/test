import React from 'react'
import { View, TouchableOpacity, Image, StyleSheet } from 'react-native'
import { height } from 'react-native-dimension'
import { navTitle } from './globalStyles'
import Images from '../constants/images'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { CustomTextBold } from '../components/CustomText/CustomText'
import { connect } from 'react-redux'

const navBarView = ({onPress, title, type, onBack}) => (
  <View style={{justifyContent: 'center'}}>
    {
      type === 'Menu'
        ? (<TouchableOpacity onPress={onPress()} style={styles.menu} hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}>
          <Image source={Images.ic_menu} />
        </TouchableOpacity>)
        : (type === 'backToRoot'
          ? (<TouchableOpacity onPress={onPress()} style={styles.menu} hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}>
            <Ionicons name='ios-arrow-back' color='black' size={height(5)} />
          </TouchableOpacity>)
          : (<TouchableOpacity onPress={() => onBack()} style={styles.menu} hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}>
            <Ionicons name='ios-arrow-back' color='black' size={height(5)} />
          </TouchableOpacity>))
    }
    <CustomTextBold style={navTitle}>{title === undefined ? 'Noah Coin' : title}</CustomTextBold>
  </View>
)
function mapStateToProps (state) {
  return {
    onBack: state.onBack
  }
}
export default connect(mapStateToProps)(navBarView)
const styles = StyleSheet.create({
  menu: {
    zIndex: 2,
    position: 'absolute'

  }
})
