import React from 'react'
import { View, TouchableOpacity, Image } from 'react-native'
import {width, height} from 'react-native-dimension'

import { navTitleMenu } from './globalStyles'
import images from '../constants/images'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { connect } from 'react-redux'
import Text from '../components/CustomText/CustomText'

class navBarMenu extends React.Component {
  render () {
    return (
      <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', backgroundColor: 'transparent', height: height(11)}}>
        <View style={{flex: 8, flexDirection: 'row', height: 'auto', justifyContent: 'flex-start', alignItems: 'center'}}>
          { this.props.type === 'main' &&
            <Image source={images.logo} style={{height: height(7), width: width(10), marginLeft: width(4)}}/>
          }
          <Text style={[navTitleMenu, {marginLeft: width(4), height: 'auto', color: 'white'}]}>{this.props.title === null ? 'Noah Coin Wallet' : this.props.title}</Text>
        </View>
        <TouchableOpacity style={{flex: 1, alignItems: 'center'}} onPress={this.props.onPress()}>
          <Ionicons name='ios-arrow-back' color='white' size={height(5)} />
        </TouchableOpacity>
      </View>
    )
  }
}
export default connect()(navBarMenu)
