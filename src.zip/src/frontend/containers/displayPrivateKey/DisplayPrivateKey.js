import React, { Component } from 'react'
import { View, Image, TouchableOpacity, Clipboard } from 'react-native'
import { connect } from 'react-redux'

import { background } from '../../global/globalStyles'
import CustomText, { CustomTextBold } from '../../components/CustomText/CustomText'
import NavBarView from '../../global/navBarView'
import Images from '../../constants/images'
import i18n from '../../global/translations'
import styles from './styles'
// Alert
import DropdownAlert from '../../components/DropdownAlert/DropdownAlert'

/**
 * NAME: DisplayPrivateKey
 * CREATOR: Chau
 * Show the private key of current Noah Main account
 * User can copy to clipboard
 */
class DisplayPrivateKey extends Component {
  constructor (props) {
    super(props)
    this.state = {
      account: this.props.account[0]
    }
    this.backToRoot = this.backToRoot.bind(this)
  }
  // Mark: Funcs
  /**
     * Copy private key to clipboard
     */
  onPressedCopy () {
    Clipboard.setString(this.state.account.privateKey)
    this.showAlert(i18n.t('TransactionHistory.Copied'))
  }
  /**
   * NAME: showAlert
   * PARAMS: message
   * Show message 
   * RETURN
   */
  showAlert (message) {
    this.dropdown.alertWithType('info', '', message)
  }
  /**
   * FUNCTION: backToRoot
   * Go back to root
   */
  backToRoot () {
    this.props.navigator.popToRoot()
  }
  // Mark: Render
  render () {
    return (
      <View style={background} >
        <NavBarView onPress={() => this.backToRoot} type='backToRoot' title={i18n.t('DisplayPrivateKey.Title')} />
        <View style={{marginTop: 10}}>
          <CustomTextBold style={styles.text}>{i18n.t('DisplayPrivateKey.YourAccount')}</CustomTextBold>
          <CustomText style={styles.text}>{this.state.account.address}</CustomText>
          <CustomTextBold style={[styles.text, { marginTop: 10 }]}>{i18n.t('DisplayPrivateKey.PrivateKey')}</CustomTextBold>
          <View style={{ justifyContent: 'space-between', alignItems: 'center', flexDirection: 'row' }}>
            <CustomText style={[styles.text, {flex: 0.92}]}>{this.state.account.privateKey}</CustomText>
            <TouchableOpacity style={[styles.buttonCopy, {flex: 0.08}]} onPress={this.onPressedCopy.bind(this)} hitSlop={{top: 10, bottom: 10, left: 10, right: 10}}>
              <Image source={Images.ic_copy} />
            </TouchableOpacity>
          </View>
        </View>
        {/* DropdownAlert */}
        <DropdownAlert
          updateStatusBar={false}
          closeInterval={1500}
          ref={(ref) => { this.dropdown = ref }}
        />
        {/* ---END---- */}
      </View>
    )
  }
}

DisplayPrivateKey.navigatorStyle = {
  navBarHidden: true
}
//  Redux 
function mapStateToProps (state) {
  return {
    account: state.account
  }
}
export default connect(mapStateToProps)(DisplayPrivateKey)
