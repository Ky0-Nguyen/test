import { StyleSheet } from 'react-native'
import { width } from 'react-native-dimension'

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    flexDirection: 'row'
  },
  text: {
    fontSize: width(4),
    color: 'black'
  },
  buttonCopy: {
    width: width(4),
    height: width(4),
    alignItems: 'flex-end',
    justifyContent: 'center'
  }
})

export default styles
