
import React, { Component } from 'react'
import { View, TouchableOpacity, Keyboard, ScrollView } from 'react-native'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setAccount } from '../../actions/accountActions'
import { setBalance, setInternet } from '../../actions/mainAction'
import EtherLib from '../../lib/noahLibrary'
import EtherScan from '../../services/etherscanService'
import QRCode from 'react-native-qrcode'
import { width, height } from 'react-native-dimension'
import styles from './styles'
import { background } from '../../global/globalStyles'
import NavBarView from '../../global/navBarView'
import CustomText, {CustomTextBold} from '../../components/CustomText/CustomText'
import { WalletTopComponents } from '../../constants/constants'
import i18n from '../../global/translations'
import DropdownAlert from '../../components/DropdownAlert/DropdownAlert'
import TransactionHistory from '../../components/transactionHistory/TransactionHistory'
import SendNoahToken from '../../components/sendNoahToken/SendNoahToken'
import ConfirmSendToken from '../../components/confirmSendToken/ConfirmSendToken'
import ReceiveToken from '../../components/receiveToken/ReceiveToken'
import Modal from 'react-native-modalbox'
import { commaGlobal } from '../../global/global-constants'
import _ from 'lodash'
import numeral from 'numeral'
import SpinnerKit from 'react-native-spinkit'
import InternetAlert from '../../components/InternetAlert/InternetAlert'

const heightOfComponent = height(65)

class WalletTop extends Component {
  constructor (props) {
    super(props)
    this.state = {
      // hide or show spiner
      visible: props.account.length === 0,
      account: props.account,
      tokenData: props.tokenData,
      revAddress: '',
      revAmount: '',
      qrCodeModalReceive: '',
      amountReceive: 0,
      balance: this.props.balance,
      preventHideKeyboard: 'never',
      dataSource: [],
      refreshing: props.account.length !== 0,
      showInternet: true,
      isShowFooter: true,
      isShowConfirmView: false,
      isClear: false
    }
    this.changeParentComponentID = this.changeParentComponentID.bind(this)
    this.switchComponents = this.switchComponents.bind(this)
    this.showAlert = this.showAlert.bind(this)
    this.openQRScanner = this.openQRScanner.bind(this)
    this.genarateQRCode = this.genarateQRCode.bind(this)
    this.openQRCodeAddress = this.openQRCodeAddress.bind(this)
    this.updateOldBalance = this.updateOldBalance.bind(this)
    this._preventHideKeyboard = this._preventHideKeyboard.bind(this)
    this.showToustInternet = this.showToustInternet.bind(this)
    this.changeBalance = this.changeBalance.bind(this)
    this._keyboardDidShow = this._keyboardDidShow.bind(this)
    this._keyboardDidHide = this._keyboardDidHide.bind(this)
  }

  async componentDidMount () {
    const { setAccount } = this.props
    const { tokenData, account } = this.state
    const accountAddress = account.length > 0 ? account[0].address : ''
    const self = this

    if (this.props.internet) {
      if (this.state.visible === false) {
        try {
          self.setState({visible: true})
          tokenData.balance = EtherLib.convertWeiToEther(
            await EtherScan.getERC20TokenAccountBalanceByContractAddress(tokenData.address, accountAddress))

          this.props.setBalance(_.round(tokenData.balance, 8).toFixed(8))
          self.setState({
            visible: false,
            balance: _.round(tokenData.balance, 8).toFixed(8)
          })
        } catch (error) {
          self.setState({
            visible: false
          })
        }
      } else {
        try {
          let accountData = EtherLib.generateWallet(null, 0)
          let newAccount = [{
            key: 0,
            address: accountData.currentReceiveAddress,
            mnemonic: accountData.mnemonic,
            privateKey: accountData.privatekey,
            accountName: 'NOAH',
            balance: 0,
            isMain: true
          }]
          setAccount(newAccount)
          self.setState({
            account: newAccount,
            visible: false
          })
        } catch (error) {
          self.setState({
            visible: false
          })
        }
      }
    }
  }

  componentWillMount () {
    this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow)
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide)
  }

  componentWillUnmount () {
    this.keyboardDidShowListener.remove()
    this.keyboardDidHideListener.remove()
  }

  _keyboardDidShow () {
    // alert('Keyboard Shown')
    this.setState({isShowFooter: false})
  }

  _keyboardDidHide () {
    // alert('Keyboard Hidden')
    this.setState({isShowFooter: true})
  }

  _preventHideKeyboard (strPrevent) {
    this.setState({
      preventHideKeyboard: strPrevent
    })
  }

  toggleDrawer = () => {
    if (!this.state.isShowConfirmView) {
      this.props.navigator.toggleDrawer({
        screen: 'noah.Drawer',
        side: 'left',
        animated: true
      })
    }
  }

  /**
   * Switch which component will be display in body of Wallet Top View
   */
  switchComponents = (_subComponentID, _revAddress, _revAmount) => {
    switch (_subComponentID) {
    case WalletTopComponents.SEND_NOAH_TOKEN:
      return this.refs.scrComponents.scrollTo({ x: 0, y: (heightOfComponent * 2), animated: true })
    case WalletTopComponents.CONFIRM_SEND_TOKEN:
      return this.gotoConfirmView()
    case WalletTopComponents.RECEIVE_TOKEN:
      return this.refs.scrComponents.scrollTo({ x: 0, y: heightOfComponent * 1, animated: true })
    default:
      return this.refs.scrComponents.scrollTo({ x: 0, y: heightOfComponent * 0, animated: true })
    }
  }

  gotoConfirmView () {
    const self = this
    this.setState({isShowConfirmView: true})
    setTimeout(function () {
      self.refs.scrComponents.scrollTo({ x: 0, y: heightOfComponent * 3, animated: true })
    }, 500)
  }

  /**
   * changeParentComponentID: change this.subComponentID from child Component
   */
  changeParentComponentID (_subComponentID, _index, _revAddress, _revAmount) {
    this.setState({
      subComponentID: _subComponentID
    })
    if (_subComponentID === WalletTopComponents.CONFIRM_SEND_TOKEN) {
      this.setState({
        revAddress: _revAddress,
        revAmount: _revAmount
      })
    }
    this.switchComponents(_subComponentID, _revAddress, _revAmount)
  }

  changeBalance (_balance) {
    this.setState({balance: _balance})
  }

  /**
   * FUNCTION: updateOldBalance
   * Update Old balance, when confirm send successful
   */
  updateOldBalance (success, message) {
    if (success) {
      this.showAlert(message)
      this.setState({isClear: true})
      this.props.setBalance(this.state.balance)
    } else {
      this.setState({balance: this.props.balance})
    }
    const self = this
    setTimeout(function () {
      self.setState({
        preventHideKeyboard: 'never',
        isShowConfirmView: false,
        isClear: false
      })
    }, 500)
  }

  /**
   * Open QR Scanner camera
   * Called from ComfirmSendToken child view
   */
  openQRScanner () {
    this.props.navigator.push({
      screen: 'noah.QrCodeScanner',
      animationType: 'slide-horizontal',
      title: i18n.t('QrCodeScanner.titleQrScanner')
    })
  }

  /**
   * NAME: showAlert
   * PARAMS: message
   * Show message 
   * RETURN
   */
  showAlert (message, type) {
    if (!type) {
      this.dropdown.alertWithType('info', '', message)
    } else if (type === 'error') {
      this.dropdown.alertWithType('error', '', message)
    }
  }

  showToustInternet () {
    this.setState({showInternet: false})
    const self = this
    setTimeout(function () {
      self.setState({showInternet: true})
    }, 200)
  }

  /**
   * FUNCTION: genarateQRCode
   * @param {*} amount 
   * Receive amount from subView Receive,
   * ganarate QRCode and show modal
   */
  genarateQRCode (amount) {
    const { account } = this.state
    let address = account.length > 0 ? account[0].address : 0
    this.setState({
      qrCodeModalReceive: address + commaGlobal.semicolon + amount,
      amountReceive: amount
    })
    this.refs.modalReceive.open()
  }

  /**
   * FUNCTION: openQRCodeAddress
   * Open QRCode for curren account address
   */
  openQRCodeAddress () {
    Keyboard.dismiss()
    if (!this.state.isShowConfirmView) {
      this.refs.modalAddress.open()
    }
  }

  /**
   * FUNCTION: QRCodePopup
   * Show modal QRCode
   */
  get QRCodePopup () {
    const { account } = this.state
    let address = account.length > 0 ? account[0].address : 0
    return (
      <View style={{ height: width(87), width: width(92), backgroundColor: 'white', paddingHorizontal: width(5), paddingTop: width(7.47), paddingBottom: width(9.5) }} elevation={10}>
        <View style={{flex: 1, justifyContent: 'space-between'}}>
          <View style={{width: width(82)}}>
            <CustomText style={{fontSize: width(3.73), color: 'black'}}>{i18n.t('WalletTop.RequestedAmount')}</CustomText>
            <CustomText style={{fontSize: width(3.73), color: 'black'}}>{this.state.amountReceive} NOAH</CustomText>
            <CustomText style={{fontSize: width(3.73), color: 'black', marginTop: height(2)}} adjustsFontSizeToFitWidth={true} numberOfLines={2}>{address}</CustomText>
          </View>
          <View pointerEvents='none' style={{ justifyContent: 'center', alignItems: 'center', alignSelf: 'center', backgroundColor: 'white', height: width(42), width: width(42) }}>
            <QRCode
              value={this.state.qrCodeModalReceive}
              size={width(40)}
              bgColor='black'
              fgColor='white'
            />
          </View>
        </View>
      </View>
    )
  }

  get QRCodeAddress () {
    const { account } = this.state
    let address = account.length > 0 ? account[0].address : 0
    return (
      <View style={{ height: width(87), width: width(92), backgroundColor: 'white', paddingHorizontal: width(5), paddingTop: width(7.47), paddingBottom: width(9.5) }} elevation={10}>
        <View style={{flex: 1, justifyContent: 'space-between'}}>
          <View style={{width: width(82)}}>
            <CustomTextBold style={{fontSize: width(3.73), color: 'black'}}>{i18n.t('WalletTop.ModalAddressTitle')}</CustomTextBold>
            <CustomText style={{fontSize: width(3.73), color: 'black', marginTop: height(2)}} adjustsFontSizeToFitWidth={true} numberOfLines={2}>{address}</CustomText>
          </View>
          <View pointerEvents='none' style={{ justifyContent: 'center', alignItems: 'center', alignSelf: 'center', backgroundColor: 'white', height: width(42), width: width(42) }}>
            <QRCode
              value={address}
              size={width(40)}
              bgColor='black'
              fgColor='white'
            />
          </View>
        </View>
      </View>
    )
  }

  render () {
    const { showInternet, visible, dataSource, refreshing, isShowFooter, isShowConfirmView, preventHideKeyboard, isClear } = this.state
    return (
      <View style={[styles.container]}>
        <View style={background}>

          <NavBarView onPress={() => this.toggleDrawer} type='Menu' title='Noah Coin' />

          <View style={[styles.balanceContainer, {height: height(18)}]} elevation={10}>
            <View style={styles.balanceBox}>
              {visible ? <SpinnerKit style={{ marginTop: width(2), marginLeft: width(2) }} isVisible={visible} size={height(5)} type={'Wave'} color={'white'} />
                : <CustomText numberOfLines={1} style={[styles.balance]}>{numeral(this.state.balance).format('0,0.00000000')}</CustomText>
              }
            </View>
            <TouchableOpacity onPress={this.openQRCodeAddress}>
              <View style={styles.qrCodeBox} pointerEvents='none'>
                <QRCode
                  size={width(25)}
                  bgColor='black'
                  fgColor='white'
                />
              </View>
            </TouchableOpacity>
          </View>

          {/* WalletTopBody */}
          <View style={{height: heightOfComponent}}>
            <ScrollView ref='scrComponents'
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps={preventHideKeyboard}
            >
              <TransactionHistory
                changeParentComponentID={this.changeParentComponentID}
                showAlert={this.showAlert}
                dataSource={dataSource}
                refreshing={refreshing}
                visible={visible}
              />
              <ReceiveToken
                changeParentComponentID={this.changeParentComponentID}
                genarateQRCode={this.genarateQRCode}
              />
              <SendNoahToken
                changeParentComponentID={this.changeParentComponentID}
                openQRScanner={this.openQRScanner}
                changeBalance={this.changeBalance}
                updateOldBalance={this.updateOldBalance}
                isClear={isClear}
              />
              {isShowConfirmView && <ConfirmSendToken
                changeParentComponentID={this.changeParentComponentID}
                revAddress={this.state.revAddress} revAmount={this.state.revAmount}
                updateOldBalance={this.updateOldBalance}
                preventHideKeyboard={this._preventHideKeyboard}
                showToustInternet={this.showToustInternet}
                showAlert={this.showAlert}
              />}
            </ScrollView>
          </View>
        </View>
        {isShowFooter &&
          <View style={{ paddingTop: width(0.5) }}>
            <View style={[styles.bottomText]}>
              <CustomText style={{ color: 'white', textAlign: 'center' }}>{i18n.t('SetupWallet.TitleFooter')}</CustomText>
            </View>
          </View>
        }

        {showInternet && <InternetAlert/>}
        <Modal
          ref='modalReceive'
          style ={{height: width(87), width: width(92)}}
          transparent={true}
          position={'center'}
          backdropPressToClose={true}>
          {this.QRCodePopup}
        </Modal>
        <Modal
          ref='modalAddress'
          style ={{height: width(87), width: width(92)}}
          transparent={true}
          position={'center'}
          backdropPressToClose={true}>
          {this.QRCodeAddress}
        </Modal>
        <DropdownAlert
          updateStatusBar={false}
          closeInterval={2500}
          ref={(ref) => { this.dropdown = ref }}
        />
      </View>
    )
  }
}

WalletTop.navigatorStyle = {
  navBarHidden: true
}

// Redux 
function mapStateToProps (state) {
  return {
    account: state.account,
    tokenData: state.tokenData,
    internet: state.internet,
    balance: state.balance
  }
}

function mapDispatchToProps (dispatch) {
  return {
    setAccount: bindActionCreators(setAccount, dispatch),
    setBalance: bindActionCreators(setBalance, dispatch),
    setInternet: bindActionCreators(setInternet, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(WalletTop)
