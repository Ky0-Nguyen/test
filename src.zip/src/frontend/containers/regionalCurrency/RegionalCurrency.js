import React, { Component } from 'react'
import {
  View
} from 'react-native'
import { width, height } from 'react-native-dimension'

// import Menu from './Menu'
import NavBarMenu from '../../global/navBarMenu'
import { whilteLine, textDefault } from '../../global/globalStyles'
// import Text from '../../components/CustomText/CustomText'
import Radio from '../../components/Radio/Radio'
import i18n from '../../global/translations'

//  redux
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setCurrency } from '../../actions/currencyActions'
// Data of type money
let datas = [
  {
    'selecteId': 0,
    'content': 'USD',
    'contentName': 'United States Dollar',
    'selected': false
  },
  {
    'selecteId': 1,
    'content': 'JPY',
    'contentName': 'Japanese Yen',
    'selected': false
  }
]
/**
 * NAME: Regional Currency
 * CREATOR: TUAN
 * default display type money
 * FUNCTION 
 * componentWillMount()
 *  _onClick()
 */
class RegionalCurrency extends Component {
  constructor (props) {
    super(props)
    this.state = {
      valueDefault: null,
      item: []
    }
  }

  componentWillMount () {
    const { currency } = this.props
    var self = this
    if (currency !== undefined && currency !== null && currency !== '') {
      datas.forEach(function (element) {
        if (currency === element.content) {
          // change valueDefault  to selecteId
          self.setState({valueDefault: element.selecteId})
        }
      })
    } else {
      this.props.setCurrency('USD')
      datas.forEach(function (element) {
        if (element.content === 'USD') {
          // change valueDefault  to selecteId
          self.setState({valueDefault: element.selecteId})
        }
      })
    }
  }
  /**
     * NAME: _onClick
     * PARAMS: item, keyAsync.Currency
     * action click
     */
  _onClick (id, item) {
    // set value of  Currency = item
    this.props.setCurrency(item)
    this.props.clickBack()
  }
  // --------_END_---------
  render () {
    return (
      <View style={{backgroundColor: '#636363', flex: 1}}>
        <NavBarMenu onPress={() => this.props.clickBack} title ={ i18n.t('Menu.CurrenceTitle') }/>
        <View style={whilteLine}/>
        <View style={{height: height(100), width: width(100)}}>
          {/* radio button view */}
          <Radio
            options={{id: 'selecteId', value: 'content', disabled: 'selected', contentName: 'contentName'}}
            innerStyle= {{ width: width(85), height: height(5), marginLeft: width(2), borderBottomWidth: 1, borderBottomColor: '#595959' }}
            txtColor={'white'}
            textStyle = {[textDefault, {color: 'white'}]}
            imageStyle = {{ height: width(4), width: width(4), marginLeft: width(1) }}
            noneColor={'#efefef'}
            key={this.state.valueDefault}
            selectedValue={this.state.valueDefault}
            onValueChange={(id, item) => this._onClick(id, item)}
            seledImg={require('./imgs/selected.png')}
            selImg={require('./imgs/select.png')}
            selnoneImg={require('./imgs/selectnone.png')}
            dataOption={datas}
            style={{ flexDirection: 'column',
              flexWrap: 'wrap',
              alignItems: 'flex-start',
              paddingTop: height(1)
            }}
          />
        </View>
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    currency: state.currency
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    setCurrency: bindActionCreators(setCurrency, dispatch)
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(RegionalCurrency)
