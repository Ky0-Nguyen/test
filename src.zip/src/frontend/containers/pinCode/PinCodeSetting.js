import React, { Component } from 'react'
import {
  View,
  TouchableHighlight,
  FlatList,
  StyleSheet
} from 'react-native'
import { width, height } from 'react-native-dimension'

// import Menu from './Menu'
import NavBarMenu from '../../global/navBarMenu'
import { whilteLine, textDefault } from '../../global/globalStyles'
import Text from '../../components/CustomText/CustomText'
import i18n from '../../global/translations'

import { connect } from 'react-redux'

/*
 * NAME: PinCodeSetting
 * CREATOR: TUAN
 * show button setup pincode, change pincode, remove pincode
 * FUNCTION
 * onClick
 * renderRow
 */
class PinCodeSetting extends Component {
  /*
  * NAME: onClick
  * PARAM: key
  * route to Wallet Detail
  */
  onClick (key) {
    switch (key) {
    case 1:
      this.props.navigator.push({
        screen: 'noah.PinCode',
        animationType: 'slide-horizontal',
        passProps: {
          types: 'SetupPinCode',
          title: i18n.t('SettingPinCode.titleSetup')
        }
      })
      this.props.toggleDrawerClose()
      break
    case 2:
      this.props.navigator.push({
        screen: 'noah.PinCode',
        animationType: 'slide-horizontal',
        passProps: {
          types: 'ChangePinCode',
          title: i18n.t('SettingPinCode.titleChange')
        }
      })
      this.props.toggleDrawerClose()
      break
    case 3:
      this.props.navigator.push({
        screen: 'noah.PinCode',
        animationType: 'slide-horizontal',
        passProps: {
          types: 'RemovePinCode',
          title: i18n.t('SettingPinCode.titleRemove')
        }
      })
      this.props.toggleDrawerClose()
      break
    default:
      break
    }
  }
  /*
  * NAME: renderRow
  * PARAM: item ->  item of list data button 
  * render button 
  */
  renderRow = ({ item }) => {
    return (
      <TouchableHighlight onPress={() => this.onClick(item.key)} underlayColor= {'orange'}>
        <View style={styles.buttonView}>
          <Text style={[textDefault, { marginLeft: width(4) }]}>{item.title}</Text>
        </View>
      </TouchableHighlight>
    )
  }
  render () {
    const data = [
      { key: 1, title: i18n.t('SettingPinCode.titleSetup') }

    ]
    const data1 = [
      { key: 2, title: i18n.t('SettingPinCode.titleChange') },
      { key: 3, title: i18n.t('SettingPinCode.titleRemove') }
    ]
    return (
      <View style={{backgroundColor: '#636363', flex: 1}}>
        <NavBarMenu onPress={() => this.props.clickBack} title ={ i18n.t('Menu.PinCodeSetting') }/>
        <View style={whilteLine}/>
        <View style={{height: height(100), width: width(100)}}>
          <FlatList
            data={!this.props.pincode ? data : data1}
            renderItem={this.renderRow} />
        </View>
      </View>
    )
  }
}

function mapStateToProps (state) {
  return {
    pincode: state.pincode
  }
}
export default connect(mapStateToProps)(PinCodeSetting)
const styles = StyleSheet.create({
  textView: {
    margin: width(1),
    height: height(10),
    marginBottom: height(1)
  },
  leftBottom: {
    height: height(89)
  },
  buttonView: {
    // borderBottomWidth: 0.5,
    width: width(100),
    // borderBottomColor: '#595959',
    height: height(7),
    justifyContent: 'center'
  },
  txtVersion: {
    color: 'white',
    fontSize: height(4),
    marginLeft: width(4),
    marginBottom: height(1)
  }
})
