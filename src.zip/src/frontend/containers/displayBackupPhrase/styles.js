import { StyleSheet } from 'react-native'
import { width, height } from 'react-native-dimension'

const styles = StyleSheet.create({
  text: {
    fontSize: width(4),
    color: 'black',
    marginBottom: height(2),
    marginTop: height(0.2)
  },
  textWhiteBox: {
    fontSize: width(3.8),
    textAlign: 'justify'
  },
  whiteBox: {
    padding: height(1.8),
    marginTop: height(1.25),
    marginBottom: height(2),
    backgroundColor: 'white'
  }
})

export default styles
