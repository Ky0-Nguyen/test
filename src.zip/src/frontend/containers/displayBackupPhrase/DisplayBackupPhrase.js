import React, { Component } from 'react'
import {View} from 'react-native'
import { connect } from 'react-redux'

import { background } from '../../global/globalStyles'
import CustomText from '../../components/CustomText/CustomText'
import NavBarView from '../../global/navBarView'
import i18n from '../../global/translations'
import styles from './styles'

/**
 * NAME: DisplayBackupPhrase
 * CREATOR: Chau
 * Show the passphrase of current Noah Main account
 */
class DisplayBackupPhrase extends Component {
  constructor (props) {
    super(props)
    this.state = ({
      passphrase: this.props.account.length > 0 ? this.props.account[0].mnemonic : ''
    })
    this.backToRoot = this.backToRoot.bind(this)
  }
  /**
   * FUNCTION: backToRoot
   * Go back to root
   */
  backToRoot () {
    this.props.navigator.popToRoot()
  }
  render () {
    return (
      <View style={background} >
        <NavBarView onPress={() => this.backToRoot} type='backToRoot' title={i18n.t('DisplayBackupPhrase.Title')} />
        <CustomText style={styles.text}>{i18n.t('DisplayBackupPhrase.String1')}</CustomText>
        <View style={styles.whiteBox} elevation={10} >
          <CustomText style={styles.textWhiteBox}>{this.state.passphrase}</CustomText>
        </View>
        <CustomText style={styles.text}>{i18n.t('DisplayBackupPhrase.String3')}</CustomText>
        <CustomText style={styles.text}>{i18n.t('DisplayBackupPhrase.String4')}</CustomText>
      </View>
    )
  }
}

DisplayBackupPhrase.navigatorStyle = {
  navBarHidden: true
}

function mapStateToProps (state) {
  return {
    account: state.account
  }
}
export default connect(mapStateToProps)(DisplayBackupPhrase)
