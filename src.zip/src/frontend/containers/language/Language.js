import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableOpacity,
  Image, NetInfo
} from 'react-native'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { ActionCreators } from '../../actions'
import { background, primaryButton, secondaryButton } from '../../global/globalStyles'
import styles from './styles'
import images from '../../constants/images'
import '../../global/global-constants'
// import { setDefaultOnback } from '../../actions'

class Language extends Component {
  constructor (props) {
    super(props)
    NetInfo.isConnected.fetch().then(isConnected => {
      this.props.setInternet(isConnected)
    })
    NetInfo.isConnected.addEventListener('change', this.handleConnectionChange)
  }
  handleConnectionChange = (isConnected) => {
    this.props.setInternet(isConnected)
  }
  onSelectLanguage (language) {
    this.props.setLanguage(language)
    this.props.navigator.push({
      screen: 'noah.SetupWallet',
      animationType: 'slide-horizontal'
    })
  }

  render () {
    return <View style={background}>
      <View style={styles.topView}>
        <Image source={images.logo} />
        <Text style={styles.noahTxt}>Noah Coin</Text>
      </View>

      <View style={styles.centerView}>
        <Text style={styles.langTxt}>Select language</Text>
      </View>

      <View style={styles.bottomView}>
        <TouchableOpacity onPress={() => this.onSelectLanguage('jp') }>
          <View style={[primaryButton, {marginBottom: 20}]}>
            <Text style={styles.textStyle}>日本語</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => this.onSelectLanguage('en') }>
          <View style={[secondaryButton, {marginBottom: 20}]}>
            <Text style={styles.textStyle}>English</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  }
}

Language.navigatorStyle = {
  navBarHidden: true
}

function mapStateToProps (state) {
  return {
    language: state.language,
    account: state.account
  }
}

function mapDispatchToProps (dispatch) {
  return bindActionCreators(ActionCreators, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(Language)
