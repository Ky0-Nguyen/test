import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  topView: {
    flex: 5,
    justifyContent: 'center',
    alignItems: 'center'
  },
  centerView: {
    flex: 0.5
  },
  bottomView: {
    flex: 4.5
  },
  noahTxt: {
    marginTop: 20,
    fontSize: 32,
    color: '#7F7F7F'
  },
  textStyle: {
    textAlign: 'center',
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18
  }
})

export default styles
