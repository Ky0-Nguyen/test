import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableOpacity,
  Image
} from 'react-native'

// redux
import { connect } from 'react-redux'

import { background, primaryButton, secondaryButton } from '../../global/globalStyles'
import styles from './styles'
import images from '../../constants/images'
import i18n from '../../global/translations'

class SetupWallet extends Component {
  onPressedCreateWallet () {
    this.props.navigator.push({
      screen: 'noah.TermOfService',
      animationType: 'slide-horizontal',
      title: 'Term of Service'
    })
  }

  onPressedRestoreWallet () {
    this.props.navigator.push({
      screen: 'noah.RestoreWallet',
      animationType: 'slide-horizontal'
    })
  }

  render () {
    return <View style={background}>
      <View style={styles.topView}>
        <Image source={images.logo} />
        <Text style={styles.noahTxt}>Noah Coin</Text>
      </View>
      <View style={styles.bottomView}>
        <TouchableOpacity onPress={() => this.onPressedCreateWallet() }>
          <View style={[primaryButton, {marginBottom: 20}]}>
            <Text style={styles.textStyle}>{i18n.t('SetupWallet.Create')}</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => this.onPressedRestoreWallet() }>
          <View style={[secondaryButton, {marginBottom: 20}]}>
            <Text style={styles.textStyle}>{i18n.t('SetupWallet.Restore')}</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => this.props.navigator.pop()}>
          <View style={{marginBottom: 20}}>
            <Text style={styles.textStyle}>{i18n.t('SetupWallet.Back')}</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  }
}

SetupWallet.navigatorStyle = {
  navBarHidden: true
}

function mapStateToProps (state) {
  return {
    account: state.account
  }
}

export default connect(mapStateToProps)(SetupWallet)
