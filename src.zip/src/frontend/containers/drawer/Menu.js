import React from 'react'
import {
  View,
  TouchableHighlight,
  FlatList,
  StyleSheet } from 'react-native'
import { width, height } from 'react-native-dimension'
import { textDefault } from '../../global/globalStyles'
import i18n from '../../global/translations'
import Text from '../../components/CustomText/CustomText'
import { connect } from 'react-redux'

/*
 * NAME: Menu
 * CREATOR: TUAN
 * list menu
 * FUNCTION
 * onClick
 * renderRow
 */
class Menu extends React.Component {
  /*
  * NAME: onClick
  * PARAM: key
  * route to Wallet Detail
  */
  onClick (key) {
    const {
      onOpenSettingPinCode,
      navigator,
      toggleDrawerClose,
      onOpenRegionalCurrency
    } = this.props
    switch (key) {
    case 1:
      onOpenRegionalCurrency()

      break
    case 2:
      onOpenSettingPinCode()

      break
    case 3:
      if (this.props.pincode) {
        navigator.push({
          screen: 'noah.PinCode',
          animationType: 'slide-horizontal',
          passProps: {
            types: 'ConfirmPinCode',
            title: i18n.t('Menu.ConfirmPinCode'),
            nextScreen: 'noah.DisplayBackupPhrase'
          }
        })
      } else {
        navigator.push({
          screen: 'noah.DisplayBackupPhrase',
          animationType: 'slide-horizontal'
        })
      }
      toggleDrawerClose()
      break
    case 4:
      if (this.props.pincode) {
        navigator.push({
          screen: 'noah.PinCode',
          animationType: 'slide-horizontal',
          passProps: {
            types: 'ConfirmPinCode',
            title: i18n.t('Menu.ConfirmPinCode'),
            nextScreen: 'noah.DisplayPrivateKey'
          }
        })
      } else {
        navigator.push({
          screen: 'noah.DisplayPrivateKey',
          animationType: 'slide-horizontal'
        })
      }
      toggleDrawerClose()
      break
    // PrivacyPolicy
    case 5:
      navigator.push({
        screen: 'noah.PrivacyPolicy',
        animationType: 'slide-horizontal',
        passProps: {
          parentView: 'Menu'
        }
      })
      toggleDrawerClose()
      break
    // TermsOfService
    case 6:
      navigator.push({
        screen: 'noah.TermOfService',
        animationType: 'slide-horizontal',
        passProps: {
          parentView: 'Menu'
        }
      })
      toggleDrawerClose()
      break
    case 7:
      navigator.push({
        screen: 'noah.AboutNoahWallet',
        animationType: 'slide-horizontal'
      })
      toggleDrawerClose()
      break
    default:
      break
    }
  }
  /*
  * NAME: renderRow
  * PARAM: item in list data menu
  * route to Wallet Detail
  */
  renderRow = ({ item }) => {
    return (
      <TouchableHighlight onPress={() => this.onClick(item.key)} underlayColor= {'orange'}>
        <View style={styles.buttonView}>
          <Text style={[textDefault, { marginLeft: width(4) }]}>{item.title}</Text>
        </View>
      </TouchableHighlight>
    )
  }
  render () {
    const data = [
      { key: 1, title: i18n.t('Menu.Currency') },
      { key: 2, title: i18n.t('Menu.PinCodeSetting') },
      { key: 3, title: i18n.t('Menu.DisplayPassphrase') },
      { key: 4, title: i18n.t('Menu.DisplayPrivateKey') },
      { key: 5, title: i18n.t('Menu.PrivacyPolicy') },
      { key: 6, title: i18n.t('Menu.TermsOfService') },
      { key: 7, title: i18n.t('Menu.About') }
    ]
    return (
      <View style={styles.leftBottom}>
        <FlatList
          data={data}
          renderItem={this.renderRow} />
        <View style={styles.textView}>
          <Text style={[styles.txtVersion]}>{i18n.t('Menu.Version')}</Text>
        </View>
      </View>
    )
  }
}

function mapStateToProps (state) {
  return {
    pincode: state.pincode
  }
}
export default connect(mapStateToProps)(Menu)

const styles = StyleSheet.create({
  textView: {
    margin: width(1),
    height: height(10),
    marginBottom: height(1)
  },
  leftBottom: {
    height: height(89)
  },
  buttonView: {
    width: width(100),
    height: height(7),
    justifyContent: 'center'
  },
  txtVersion: {
    color: 'white',
    fontSize: height(2),
    marginLeft: width(4),
    marginBottom: height(1)
  }
})
