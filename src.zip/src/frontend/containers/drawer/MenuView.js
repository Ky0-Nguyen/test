import React, { Component } from 'react'
import {
  View
} from 'react-native'

import Menu from './Menu'
import NavBarMenu from '../../global/navBarMenu'
import { whilteLine } from '../../global/globalStyles'

import { connect } from 'react-redux'
/*
 * NAME: MenuView
 * CREATOR: TUAN
 * render view menu  , navbar, menu
 * FUNCTION
 * onClick
 * renderRow
 */
class MenuView extends Component {
  render () {
    const {
      onOpenSettingPinCode,
      toggleDrawerClose,
      onOpenRegionalCurrency,
      navigator } = this.props
    return (
      <View style={{backgroundColor: '#636363', flex: 1}}>
        <NavBarMenu
          onPress={() => this.props.toggleDrawerClose()}
          type='main' title ='Noah Coin Wallet'/>
        <View style={whilteLine}/>
        <Menu
          navigator={navigator}
          onOpenSettingPinCode={onOpenSettingPinCode}
          toggleDrawerClose={toggleDrawerClose()}
          onOpenRegionalCurrency = {onOpenRegionalCurrency}/>
      </View>
    )
  }
}

function mapStateToProps (state) {
  return {
    language: state.language
  }
}
export default connect(mapStateToProps)(MenuView)
