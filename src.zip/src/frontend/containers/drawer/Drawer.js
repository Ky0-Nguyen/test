import React, { Component } from 'react'

import CustomComponents from 'react-native-deprecated-custom-components'

import MenuView from './MenuView'
import SettingPINCode from './../pinCode/PinCodeSetting'
import RegionalCurrency from './../regionalCurrency/RegionalCurrency'

import { connect } from 'react-redux'

/*
 * NAME: Drawer
 * CREATOR: TUAN
 * show menu drawer
 * FUNCTION
 * toggleDrawerClose
 * renderScene
 */
class Drawer extends Component {
  /*
  * NAME: toggleDrawerClose
  * close menu
  */
  toggleDrawerClose = () => {
    this.props.navigator.toggleDrawer({
      side: 'left',
      animated: true,
      to: 'closed'
    })
  }
  /*
  * NAME: renderScene
  * renderScene router to view
  */
  renderScene (route, navigator) {
    switch (route.name) {
    case 'menu' :
      return (
        <MenuView
          toggleDrawerClose ={() => this.toggleDrawerClose}
          onOpenSettingPinCode= {() => navigator.push({name: 'SettingPINCode'})}
          onOpenRegionalCurrency= {() => navigator.push({name: 'RegionalCurrency'})}
          clickBack = {this.props.clickBack}
          navigator = {this.props.navigator} />
      )
    case 'SettingPINCode' :
      return (
        <SettingPINCode
          navigator={this.props.navigator}
          clickBack = {() => { navigator.pop({name: 'menu'}) }}
          toggleDrawerClose ={this.toggleDrawerClose}/>
      )
    case 'RegionalCurrency' :
      return (
        <RegionalCurrency
          clickBack = {() => { navigator.pop({name: 'menu'}) }}/>
      )
    }
  }
  render () {
    return (
      <CustomComponents.Navigator
        initialRoute = {{name: 'menu'}}
        renderScene = {this.renderScene.bind(this)}
      />
    )
  }
}

function mapStateToProps (state) {
  return {
    language: state.language
  }
}
export default connect(mapStateToProps)(Drawer)
