import { StyleSheet } from 'react-native'
import { width } from 'react-native-dimension'

const styles = StyleSheet.create({
  text: {
    fontSize: width(3.7),
    color: 'black'
  }
})

export default styles
