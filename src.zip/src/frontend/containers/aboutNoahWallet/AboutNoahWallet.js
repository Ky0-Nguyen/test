import React from 'react'
import { View, ScrollView } from 'react-native'
import { connect } from 'react-redux'

import { background } from '../../global/globalStyles'
import CustomText from '../../components/CustomText/CustomText'
import NavBarView from '../../global/navBarView'
import i18n from '../../global/translations'
import styles from './styles'

/**
 * NAME: AboutNoahWallet
 * CREATOR: Chau
 * Screen is discription about this app
 */
const AboutNoahWallet = () => (
  <View style={background} >
    <NavBarView onPress={() => console.log('back')} type='Back' title={i18n.t('AboutNoahWallet.Title')} />
    <ScrollView style={{ marginTop: 10, flex: 1 }}>
      <CustomText style={styles.text}>{i18n.t('AboutNoahWallet.About')}</CustomText>
    </ScrollView>
  </View>
)

AboutNoahWallet.navigatorStyle = {
  navBarHidden: true
}

export default connect()(AboutNoahWallet)
