import React, { Component } from 'react'
import { View, Vibration, Animated, Easing } from 'react-native'
import { width, height } from 'react-native-dimension'
import Camera from 'react-native-camera'
import { colorsLink } from '../../global/globalStyles'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { setQRCode } from '../../actions/mainAction'
import NavBarView from '../../global/navBarView'
import i18n from '../../global/translations'
/**
 * NAME: QrCodeScanner
 * CREATOR: TUAN
 * QrCode Scan
 * FUNCTION
 * componentWillMount()
 * scanLineAnimation()
 * onRouteTo()
 * onBarCodeRead()
 */
class QrCodeScanner extends Component {
  // define props and state of function
  constructor (props) {
    super(props)
    this.state = {
      scanTranslte: new Animated.Value(0),
      scanSuccess: false,
      results: ''
    }
  }
  /*
  * NAME: componentDidMount
  */
  componentDidMount () {
    this.scanLineAnimation()
  }
  /*
  * NAME: scanLineAnimation
  * scan Line run
  */
  scanLineAnimation () {
    Animated.sequence([
      Animated.timing(this.state.scanTranslte, {
        toValue: 200,
        duration: 3000,
        easing: Easing.linear
      }),
      Animated.timing(this.state.scanTranslte, {
        toValue: 0,
        duration: 3000,
        easing: Easing.linear
      })
    ]).start(() => this.scanLineAnimation())
  }

  componentWillUnmout () {
    this.camera && this.camera.shouldQR()
  }

  /*
  * NAME: onBarCodeRead
  * read qrcode, barcode
  */
  onBarCodeRead (results) {
    if (results.data !== this.state.results) {
      this.setState({ results: results.data })
      Vibration.vibrate()

      this.props.setQRCode(results.data)
      this.props.navigator.pop()
      this.props.setQRCode('')
    }
  }
  render () {
    const scanCoverColor = '#44444488'
    const scanRectWidth = width(70)
    return (
      <View style={{ flex: 1 }}>
        <View style={{paddingHorizontal: width(4), paddingVertical: width(3), backgroundColor: '#DDDDDD'}}>
          <NavBarView onPress={() => console.log('back')} type='Back' title={i18n.t('QrCodeScanner.titleQrScanner')} />
        </View>
        <View style={{ height: height(100), backgroundColor: colorsLink.default }}>

          <Camera style={{ width: width(100), height: height(85) }}
            type={Camera.constants.Type.back}
            ref={(cam) => { this.camera = cam }}
            onBarCodeRead={this.onBarCodeRead.bind(this)} />

          {/* Rounded camera */}
          <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }}>
            <View style={{ width: width(100), height: scanRectWidth / 2, backgroundColor: scanCoverColor, flexDirection: 'row' }}>
              <View style={{ borderBottomWidth: 4, borderBottomColor: 'blue', width: scanRectWidth / 7 + 4, height: scanRectWidth / 2, marginLeft: (width(100) - scanRectWidth) / 2 - 4 }} />
              <View style={{ borderBottomWidth: 4, borderBottomColor: 'blue', width: scanRectWidth / 7 + 4, height: scanRectWidth / 2, marginLeft: scanRectWidth - (scanRectWidth / 3.5) }} />
            </View>
            <View style={{ width: width(100), height: scanRectWidth, flexDirection: 'row' }}>
              <View style={{ flex: 1, backgroundColor: scanCoverColor }}>
                <View style={{ borderRightWidth: 4, borderRightColor: 'blue', height: scanRectWidth / 7 }} />
                <View style={{ borderRightWidth: 4, borderRightColor: 'blue', height: scanRectWidth / 7, marginTop: scanRectWidth - (scanRectWidth / 3.5) }} />
              </View>
              <View style={{ width: scanRectWidth }}>
                <Animated.View style={{ width: scanRectWidth, height: 2, backgroundColor: '#1dacf9', transform: [{ translateY: this.state.scanTranslte }] }} />
              </View>
              <View style={{ flex: 1, backgroundColor: scanCoverColor }}>
                <View style={{ borderLeftWidth: 4, borderLeftColor: 'blue', height: scanRectWidth / 7 }} />
                <View style={{ borderLeftWidth: 4, borderLeftColor: 'blue', height: scanRectWidth / 7, marginTop: scanRectWidth - (scanRectWidth / 3.5) }} />
              </View>
            </View>
            <View style={{ flex: 1, width: width(100), backgroundColor: scanCoverColor, flexDirection: 'row' }}>
              <View style={{ borderTopWidth: 4, borderTopColor: 'blue', width: scanRectWidth / 7 + 4, height: scanRectWidth / 2, marginLeft: (width(100) - scanRectWidth) / 2 - 4 }} />
              <View style={{ borderTopWidth: 4, borderTopColor: 'blue', width: scanRectWidth / 7 + 4, height: scanRectWidth / 2, marginLeft: scanRectWidth - (scanRectWidth / 3.5) }} />
            </View>
          </View>

        </View>
      </View>
    )
  }
}

QrCodeScanner.navigatorStyle = {
  navBarHidden: true
}

const mapDispatchToProps = (dispatch) => {
  return {
    setQRCode: bindActionCreators(setQRCode, dispatch)
  }
}
export default connect(null, mapDispatchToProps)(QrCodeScanner)
