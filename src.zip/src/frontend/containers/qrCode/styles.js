import {StyleSheet} from 'react-native'

import {width, height} from 'react-native-dimension'
import { colors, font } from '../../config/global-styles'

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.default,
    flex: 1
  },
  title: {
    color: 'white',
    fontSize: font.normal + width(2),
    fontWeight: 'bold'
  },
  rightNavBar: {
    color: 'white',
    fontSize: 30,
    marginTop: height(1)
  },
  backgroundImage: {
    height: height(100),
    alignSelf: 'stretch',
    width: width(100),
    backgroundColor: 'transparent'
  },
  topContent: {margin: width(4), height: height(15), borderWidth: 2, opacity: 1, borderColor: 'white'},
  bottomContent: {margin: width(4), marginTop: 0, height: height(30)},
  textContent: {fontSize: font.normal + width(1), paddingTop: height(1), color: 'white'}
})
export default styles
