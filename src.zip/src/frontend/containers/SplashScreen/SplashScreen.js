import React, { Component } from 'react'
import { Image, NetInfo, View } from 'react-native'
import { width, height } from 'react-native-dimension'
// Other Components
import { connect } from 'react-redux'
import images from '../../constants/images'
import { bindActionCreators } from 'redux'
import { setInternet } from '../../actions/mainAction'
import { setOnBack } from '../../actions/buttonActions'

/**
 * NAME: SPLASH SCREEN
 * CREATOR: Chau
 * Display Splash Screen for HBWallet
 */
class SplashScreen extends Component {
  componentWillMount () {
    this.props.setOnBack(this.onBack.bind(this))

    NetInfo.isConnected.addEventListener('change', this.handleConnectionChange)
    // SET time for display splash screen
    if (this.props.account.length > 0) {
      this.props.navigator.resetTo({
        screen: 'noah.WalletTop',
        animationType: 'slide-horizontal'
      })
    } else {
      this.props.navigator.resetTo({
        screen: 'noah.Language',
        animationType: 'slide-horizontal'
      })
    }
  }

  onBack () {
    this.props.navigator.pop({
      animated: true, // does the pop have transition animation or does it happen immediately (optional)
      animationType: 'slide-horizontal' // 'fade' (for both) / 'slide-horizontal' (for android) does the pop have different transition animation (optional)
    })
  }
  // Handle Connection when internet Change
  handleConnectionChange = (isConnected) => {
    this.props.setInternet(isConnected)
  }

  // |------------------------------|
  // |--- RENDER MAIN VIEW START ---|
  // |------------------------------|
  render () {
    return (
      <View style={{flex: 1, backgroundColor: 'white'}}>
        <Image source={images.splash} style={{width: width(100), height: height(100), resizeMode: 'stretch'}} />
      </View>
    )
  }
}

SplashScreen.navigatorStyle = {
  navBarHidden: true
}
// Redux Content
const mapStateToProps = (state) => {
  return {
    account: state.account
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    setInternet: bindActionCreators(setInternet, dispatch),
    setOnBack: bindActionCreators(setOnBack, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SplashScreen)
