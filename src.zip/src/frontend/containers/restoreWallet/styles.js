import {
  StyleSheet
} from 'react-native'
import { height, width } from 'react-native-dimension'

const styles = StyleSheet.create({
  view1: {
    height: height(6),
    justifyContent: 'center',
    alignItems: 'center'
  },
  view2: {
    height: height(25)
  },
  view3: {
    height: height(10),
    justifyContent: 'center',
    alignItems: 'center'
  },
  textInput: {
    height: height(15),
    backgroundColor: 'white',
    color: 'black',
    textAlign: 'center',
    padding: width(2)
  },
  btn: {
    height: 'auto',
    width: 'auto'
  }
})
export default styles
