import React, { Component } from 'react'
import {
  View,
  TouchableOpacity,
  TextInput, Keyboard
} from 'react-native'
import { connect } from 'react-redux'
import { height } from 'react-native-dimension'
import Spinner from 'react-native-loading-spinner-overlay'
// redux
import { bindActionCreators } from 'redux'
import { setAccount } from '../../actions/accountActions'

// Alert
import DropdownAlert from '../../components/DropdownAlert/DropdownAlert'

// lib of blockchain
import bip39 from 'bip39'
import EtherLib from '../../lib/noahLibrary'

// Ionicons
import Ionicons from 'react-native-vector-icons/Ionicons'

import Text from '../../components/CustomText/CustomText'
import NavBarView from '../../global/navBarView'
import { background, textDefault, colors } from '../../global/globalStyles'
import i18n from '../../global/translations'
// styles 
import styles from './styles'

/**
 * NAME: RestoreWallet
 * CREATOR: TUAN
 * restore wallet with passphrase 
 * FUNCTION
 * onPressedNext
 */

class RestoreWallet extends Component {
  constructor (props) {
    super(props)
    this.state = {
      mnemonic: '',
      visible: false
    }
    this.onPressedNext = this.onPressedNext.bind(this)
  }

  /*
  * NAME: onPressedNext
  * PARAM:
  * push to screen Terms of service
  */
  async onPressedNext () {
    const { mnemonic } = this.state
    const { setAccount, navigator } = this.props
    Keyboard.dismiss()
    this.setState({visible: true})
    const self = this
    // Checking Mnemonic type
    if (bip39.validateMnemonic(mnemonic) === true) {
      // this.props.setMnemonic(mnemonic)
      setTimeout(async function () {
        let accountData = await EtherLib.generateWallet(mnemonic, 0)
        let newaccount = [{
          key: 0,
          address: accountData.currentReceiveAddress,
          mnemonic: accountData.mnemonic,
          privateKey: accountData.privatekey,
          accountName: 'NOAH',
          balance: 0,
          isMain: true
        }]
        setAccount(newaccount)
        navigator.push({
          screen: 'noah.TermOfService',
          animationType: 'slide-horizontal',
          title: 'Term of Service'
        })
        self.setState({visible: false})
      }, 500)
    } else {
      this.showAlert(i18n.t('RestoreWallet.error'))
      this.setState({visible: false})
    }
  }
  /**
   * NAME: showAlert
   * PARAMS: message
   * Show message error
   * RETURN
   */
  showAlert (message) {
    this.dropdown.alertWithType('error', '', message)
  }
  render () {
    const { visible } = this.state
    return (
      <View style={{flex: 1}}>
        <Spinner visible={visible} textContent={'Loading...'} textStyle={{ color: 'white', fontSize: 15 }} />
        <View style={background}>
          {/* Navigator */}
          <NavBarView type='Back' title = {i18n.t('SetupWallet.Restore')}/>
          <View style= {styles.view1}>
            <Text>{i18n.t('RestoreWallet.message')}</Text>
          </View>
          <View style= {styles.view2}>
            <TextInput
              style={[textDefault, styles.textInput]}
              placeholder={i18n.t('RestoreWallet.enter')}
              underlineColorAndroid={'transparent'}
              elevation={10}
              numberOfLines={2}
              multiline={true}
              onChangeText={text => this.setState({ mnemonic: text })}/>
          </View>
          <View style= {styles.view3}>
            <TouchableOpacity style= {styles.btn} elevation={10} onPress={() => this.onPressedNext()}>
              <Ionicons name ={'ios-checkmark-circle'} size= {height(8)} color={colors.primary}/>
            </TouchableOpacity>
          </View>
          {/* DropdownAlert */}
          <DropdownAlert
            updateStatusBar={false}
            closeInterval={1500}
            ref={(ref) => { this.dropdown = ref }}
          />
          {/* ---END---- */}
        </View>
      </View>
    )
  }
}
RestoreWallet.navigatorStyle = {
  navBarHidden: true
}
//  Redux 
function mapStateToProps (state) {
  return {
    account: state.account
  }
}
function mapDispatchToProps (dispatch) {
  return {
    setAccount: bindActionCreators(setAccount, dispatch)
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(RestoreWallet)
